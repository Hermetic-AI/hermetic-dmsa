# PMD — Provenance-aware Memory DAG

PMD is a small, dependency-light Python library that gives a memory
substrate the one thing every 16-system audit found missing:
**prompt-level lineage, with reversibility.** Every node carries the
exact LLM call that produced it, every edge is typed, and the graph
can be snapshotted, rolled back, and diffed.

The architecture is specified in `analysis/01b_pmd_architecture.md`; the
empirical motivation comes from `analysis/01a_provenance_ground_truth_audit.md`.

## Quick start

```bash
# from the pmd_skeleton/ directory
pip install -e .
python examples/01_quickstart.py
```

The example uses a hash-based embedder and a static backward deriver —
no API key, no LLM cost, fully deterministic.

```python
from pmd import ProvenanceDAG, EdgeType
from pmd.api.add import MemoryRequest, add_memory
from pmd.core.prompt import PromptContext
from pmd.store import create_store
from pmd.utils.embed import DeterministicEmbedder

dag = ProvenanceDAG(
    store=create_store("memory"),
    embedder=DeterministicEmbedder(dim=128),
)
root = add_memory(dag, MemoryRequest(
    content="the root of all memory",
    prompt_context=PromptContext(agent_id="agent_0", user_prompt="root"),
))
child = add_memory(dag, MemoryRequest(
    content="a derived thought",
    parents=[root.id],
    prompt_context=PromptContext(agent_id="agent_0", user_prompt="derive"),
))
print(dag.get_ancestors(child.id, depth=5))
```

## Architecture

```
Layer 1 (Application)   : your agent, cognee, textgrad, hebb-mind
Layer 2 (API)           : pmd.api.add / backward / lineage / version
Layer 3 (Orchestrator)  : in-process in pmd.core.dag.ProvenanceDAG
Layer 4 (Core DAG)      : MemoryNode, CreatorEdge, PromptContext,
                           VersionSnapshot, DAGDiff, enums
Layer 5 (Storage)       : ProvenanceStore (Protocol)
                           InMemoryStore | SQLiteStore | (Neo4j)
Layer 6 (Infrastructure): pmd.utils.ids / embed / serialization
```

The dependency rule is strict downward: Layer *N* may only import
from layers *< N*. Layer 4 is pure-Python; all state lives in
Layer 5.

## API surface

Public symbols (re-exported from `pmd`):

| Symbol | Description |
|---|---|
| `ProvenanceDAG` | The main orchestrator class |
| `MemoryNode`, `CreatorEdge` | Immutable record types |
| `PromptContext` | A single LLM-call record |
| `VersionSnapshot`, `DAGDiff`, `VersionChain` | Reversibility primitives |
| `EdgeType`, `ContentType`, `NodeStatus`, `PropagationStrategy`, `FeedbackSource` | Closed enums |
| `add_memory`, `backward`, `get_ancestors`, `get_descendants`, `get_lineage_path` | Convenience helpers |
| `DeterministicEmbedder`, `SentenceTransformerEmbedder` | Built-in embedders |

The exceptions (all derived from `PMDError`):

| Code | Exception |
|---|---|
| `PMD-2000` | `StorageError` |
| `PMD-2100` | `DiskFullError` |
| `PMD-3000` | `CycleDetectedError` |
| `PMD-3001` | `MissingParentError` |
| `PMD-3002` | `DanglingEdgeError` |
| `PMD-3003` | `DuplicateEdgeError` |
| `PMD-4000` | `BackwardPropagationError` |
| `PMD-5000` | `VersionConflictError` |
| `PMD-6000` | `LineageNotFoundError` |
| `PMD-7000` | `RequiresGradViolationError` |
| `PMD-8000` | `EmbeddingError` |

## Integration bridges

| Bridge | Status | Notes |
|---|---|---|
| `cognee_bridge` | ✅ Scaffolded | Lazy import; add to DAG via `CogneeBridge.wrap_datapoint` |
| `textgrad_bridge` | ✅ Scaffolded | `TrackedVariable` mirrors `forward()` / `backward()` into PMD |
| `hebb_bridge` | ✅ Scaffolded | `wrap_memory` + `record_consolidation` for the audit's lost-edge gap |

Each bridge degrades gracefully when its dependency is missing.

## Development

```bash
# install dev dependencies
pip install -e ".[dev]"

# run tests
pytest tests/ -v

# lint
ruff check pmd tests

# type-check
mypy pmd
```

## Roadmap

- **0.2** — Production hardening: WAL connection pool, per-node locks,
  metrics, async public API, snapshot compaction.
- **0.5** — ANN vector backend (HNSW), Neo4j store, multi-DC
  replication primitives.
- **1.0** — Stable data model, audited backward pass, the lineage-aware
  retrieval benchmark ≥ 10% over cosine on a public HotpotQA slice.

## License

Apache 2.0.
