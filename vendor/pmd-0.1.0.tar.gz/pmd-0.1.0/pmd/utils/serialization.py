"""JSON + msgpack codecs for PMD models.

JSON is the wire format. msgpack is the storage format when the user
opts into a binary compact representation (e.g. for a snapshot file
on S3). Both functions are Pydantic-aware: they accept a model class
and round-trip the validation.
"""

from __future__ import annotations

import json
from typing import Any, Type, TypeVar

T = TypeVar("T")

try:
    import msgpack  # type: ignore[import-untyped]

    _HAVE_MSGPACK = True
except Exception:  # pragma: no cover - optional dep
    _HAVE_MSGPACK = False


def to_json(model: Any) -> str:
    """Serialise a Pydantic model (or any ``model_dump``-able) to JSON.

    We use ``mode="json"`` so the output is JSON-safe: enums become
    their values, datetimes become strings, etc. The output is
    deterministic up to model field ordering (which is class-level
    and stable).
    """
    if hasattr(model, "model_dump_json"):
        return model.model_dump_json()
    if hasattr(model, "model_dump"):
        return json.dumps(model.model_dump(mode="json"), default=str)
    raise TypeError(f"cannot serialise {type(model).__name__} to JSON")


def from_json(model_cls: Type[T], blob: str | bytes) -> T:
    """Inverse of :func:`to_json`.

    Accepts either ``str`` or ``bytes`` (decoded as UTF-8).
    """
    if isinstance(blob, bytes):
        blob = blob.decode("utf-8")
    if hasattr(model_cls, "model_validate_json"):
        return model_cls.model_validate_json(blob)  # type: ignore[attr-defined]
    if hasattr(model_cls, "model_validate"):
        return model_cls.model_validate(json.loads(blob))  # type: ignore[attr-defined]
    raise TypeError(f"cannot deserialise into {model_cls.__name__}")


def to_msgpack(model: Any) -> bytes:
    """Serialise to msgpack. Requires the optional ``msgpack`` dep.

    Falls back to a JSON-encoded ``msgpack`` payload if the binary
    module isn't installed, so a misconfigured environment still
    works (just with a different wire format).
    """
    payload = model.model_dump(mode="json") if hasattr(model, "model_dump") else model
    if _HAVE_MSGPACK:
        return msgpack.packb(payload, use_bin_type=True)
    return json.dumps(payload, default=str).encode("utf-8")  # pragma: no cover


def from_msgpack(model_cls: Type[T], blob: bytes) -> T:
    """Inverse of :func:`to_msgpack`. Same fallback as above."""
    if _HAVE_MSGPACK:
        payload = msgpack.unpackb(blob, raw=False)
    else:  # pragma: no cover
        payload = json.loads(blob.decode("utf-8"))
    if hasattr(model_cls, "model_validate"):
        return model_cls.model_validate(payload)  # type: ignore[attr-defined]
    raise TypeError(f"cannot deserialise into {model_cls.__name__}")


__all__ = ["to_json", "from_json", "to_msgpack", "from_msgpack"]
