"""Pluggable embedder interface.

PMD never calls an LLM directly. Embedding is one of two places where
the library touches an external model (the other is the backward
deriver). The contract is small and stable: ``embed`` and
``embed_batch`` returning a fixed-dim ``list[float]`` per input.

The deterministic embedder is the workhorse for tests and the
example: it hashes the input text into a 384-d float vector that is
*stable across runs* but pseudo-random across texts. Two identical
inputs always collide at cosine 1.0; two different inputs have
cosine ≈ 0.
"""

from __future__ import annotations

import hashlib
import math
from typing import Iterable, Protocol, runtime_checkable


@runtime_checkable
class Embedder(Protocol):
    """The contract every embedder satisfies.

    Implementations may be backed by OpenAI, Sentence-Transformers,
    Cohere, a hash function, or a custom model. The DAG only requires
    that :meth:`embed` returns a 1-D ``list[float]`` of fixed
    dimensionality :attr:`dim` for any input string.
    """

    name: str
    dim: int

    def embed(self, text: str) -> list[float]: ...

    def embed_batch(self, texts: Iterable[str]) -> list[list[float]]: ...


class DeterministicEmbedder:
    """Hash-based embedder. No model, no network, deterministic.

    Each text is hashed with SHA-512; the digest is split into 32-bit
    chunks and normalised to a unit vector. The default dimensionality
    is 384; pass ``dim=1536`` to mimic OpenAI's
    ``text-embedding-3-small``.

    Two properties make this useful for tests and the runnable
    example:

    - **Determinism**: ``embed("foo") == embed("foo")`` always.
    - **Pseudo-orthogonality**: SHA-512 outputs are uniformly
      distributed, so two different inputs have cosine ≈ 0
      in expectation.
    """

    def __init__(self, dim: int = 384, name: str = "deterministic-v1") -> None:
        if dim <= 0 or dim % 32 != 0:
            raise ValueError("dim must be a positive multiple of 32")
        self.dim = dim
        self.name = name

    def embed(self, text: str) -> list[float]:
        """Hash ``text`` to a unit-norm float32 vector of length :attr:`dim`."""
        # Use a counter to extend SHA-512 output beyond 64 bytes.
        chunks: list[int] = []
        counter = 0
        while len(chunks) * 4 < self.dim:
            digest = hashlib.sha512(
                f"{counter}:{text}".encode("utf-8")
            ).digest()
            for i in range(0, len(digest), 4):
                chunks.append(int.from_bytes(digest[i : i + 4], "big", signed=True))
                if len(chunks) * 4 >= self.dim:
                    break
            counter += 1
        # Convert to floats in [-1, 1] and normalise to unit length.
        ints = chunks[: self.dim // 4]
        floats = [(i / (1 << 31)) for i in ints]
        norm = math.sqrt(sum(f * f for f in floats))
        if norm == 0.0:
            return [0.0] * self.dim
        return [f / norm for f in floats]

    def embed_batch(self, texts: Iterable[str]) -> list[list[float]]:
        return [self.embed(t) for t in texts]


class SentenceTransformerEmbedder:
    """Lazy wrapper around the ``sentence-transformers`` package.

    The dependency is *lazy* so a test environment that never calls
    ``embed`` does not need sentence-transformers installed. The
    class is constructed in two stages: ``__init__`` only validates
    the arguments, :meth:`_ensure_model` is called on the first
    ``embed`` invocation.
    """

    def __init__(
        self,
        model_name: str = "all-MiniLM-L6-v2",
        device: str | None = None,
    ) -> None:
        self.name = f"sentence-transformers/{model_name}"
        self._model_name = model_name
        self._device = device
        self._model: Any = None
        # MiniLM produces 384-d vectors. We populate the real dim once
        # the model is loaded.
        self.dim = 384

    def _ensure_model(self) -> None:
        if self._model is not None:
            return
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:  # pragma: no cover - optional dep
            raise ImportError(
                "sentence-transformers is not installed; "
                "pip install sentence-transformers to use this embedder"
            ) from exc
        self._model = SentenceTransformer(self._model_name, device=self._device)
        # ``get_sentence_embedding_dimension`` is the stable API.
        self.dim = int(self._model.get_sentence_embedding_dimension())

    def embed(self, text: str) -> list[float]:
        self._ensure_model()
        vec = self._model.encode(text, convert_to_numpy=True)
        return vec.astype("float32").tolist()

    def embed_batch(self, texts: Iterable[str]) -> list[list[float]]:
        self._ensure_model()
        vecs = self._model.encode(list(texts), convert_to_numpy=True)
        return [v.astype("float32").tolist() for v in vecs]


def embed_batch(embedder: Embedder, texts: Iterable[str]) -> list[list[float]]:
    """Convenience: route to :meth:`Embedder.embed_batch`.

    This is a thin wrapper so callers can do
    ``embed_batch(embedder, texts)`` without importing the embedder
    protocol at the call site.
    """
    return embedder.embed_batch(texts)


__all__ = [
    "Embedder",
    "DeterministicEmbedder",
    "SentenceTransformerEmbedder",
    "embed_batch",
]
