"""Layer 6 — leaf-level utility code.

Re-exports the three utility modules. PMD-internal code may import from
here freely; this is the bottom of the dependency stack.
"""

from __future__ import annotations

from pmd.utils.ids import (
    content_hash,
    generate_id,
    is_valid_id,
    snowflake_id,
)
from pmd.utils.embed import (
    DeterministicEmbedder,
    Embedder,
    SentenceTransformerEmbedder,
    embed_batch,
)
from pmd.utils.serialization import (
    from_json,
    from_msgpack,
    to_json,
    to_msgpack,
)

__all__ = [
    "generate_id",
    "content_hash",
    "is_valid_id",
    "snowflake_id",
    "Embedder",
    "DeterministicEmbedder",
    "SentenceTransformerEmbedder",
    "embed_batch",
    "to_json",
    "from_json",
    "to_msgpack",
    "from_msgpack",
]
