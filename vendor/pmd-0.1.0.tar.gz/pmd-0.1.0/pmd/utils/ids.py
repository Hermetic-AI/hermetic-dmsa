"""Stable ID generation.

PMD uses ULIDs as the canonical identifier (sortable, 128-bit, URL-
safe). We depend on the lightweight ``ulid-py`` package; the more
capable ``python-ulid`` package is intentionally avoided to keep the
install footprint small.

This module is leaf-level: it depends only on the standard library
plus ``ulid-py`` and must not import from any other PMD module.
"""

from __future__ import annotations

import hashlib
import time
import uuid
from typing import Any

try:
    import ulid as _ulid  # type: ignore[import-untyped]

    _HAVE_ULID = True
except Exception:  # pragma: no cover - defensive
    _HAVE_ULID = False


def generate_id() -> str:
    """Generate a fresh ULID string (26 chars, sortable by time).

    ULIDs encode a 48-bit millisecond timestamp and 80 bits of random
    entropy. They sort lexicographically the same way they sort
    chronologically, which is what makes them a good primary key in
    a time-ordered store.

    If the ``ulid`` package is unavailable, we fall back to a UUID4
    string. The 26-vs-36 character difference is invisible to the
    rest of the system because IDs are opaque.
    """
    if _HAVE_ULID:
        # ``ulid.new()`` returns a ``ULID`` instance whose str() is the
        # 26-char Crockford base32 encoding.
        return str(_ulid.new())
    return str(uuid.uuid4())


def content_hash(content: str) -> str:
    """SHA-256 hex digest of ``content`` encoded as UTF-8.

    Used by the backward-pass gradient cache and the dedup table to
    spot identical inputs without re-querying the LLM.
    """
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def is_valid_id(value: Any) -> bool:
    """Best-effort syntactic check that ``value`` looks like a PMD ID.

    We accept any non-empty string up to 40 characters that does not
    contain whitespace. This is *not* a full ULID/UUID validation —
    it is a guard against obvious typos (e.g. ``None``, ``""``,
    ``"  "``).
    """
    if not isinstance(value, str):
        return False
    if not value or len(value) > 40:
        return False
    return not value.isspace()


# Epoch for the snowflake implementation. We use the Unix epoch
# directly — the 41-bit timestamp field of a snowflake overflows in
# year 2080, which is well past this library's support horizon.
_SNOWFLAKE_EPOCH_MS = 0

# Sequence counter. We use a per-process counter (not thread-safe) —
# the snowflake is a *fallback* for callers who can't install ulid-py,
# and a busy agent has bigger problems than 12 bits of sequence
# exhaustion.
_snowflake_seq = 0


def snowflake_id() -> str:
    """Discord-style 64-bit snowflake, hex-encoded.

    Layout: 41 bits ms timestamp | 10 bits worker id (always 0 here)
    | 12 bits sequence.

    Provided for completeness; the default ID scheme is ULID.
    """
    global _snowflake_seq
    now_ms = int(time.time() * 1000) - _SNOWFLAKE_EPOCH_MS
    _snowflake_seq = (_snowflake_seq + 1) & 0xFFF  # 12 bits
    value = (now_ms << 22) | (0 << 12) | _snowflake_seq
    # Unsigned 64-bit; Python ints are unbounded so the masking is
    # purely for output width.
    return format(value & 0xFFFFFFFFFFFFFFFF, "016x")


__all__ = ["generate_id", "content_hash", "is_valid_id", "snowflake_id"]
