"""Bridge to `cognee` — extends the audit's anchor #1 (`DataPoint`).

Cognee already has schema-level provenance (``source_pipeline``,
``source_task``, ``topological_rank``). The bridge adds the
PMD-specific fields:

- ``creator_prompt_id`` — the prompt that produced the data point.
- ``creator_agent_id`` — the agent that ran the pipeline.
- ``parents`` — list of PMD node IDs the data point was derived from.

Cognee is imported lazily so installing PMD does not require it.
"""

from __future__ import annotations

import importlib
import time
from typing import Any

from pmd.core.dag import ProvenanceDAG
from pmd.core.enums import ContentType
from pmd.core.node import MemoryNode
from pmd.core.prompt import PromptContext
from pmd.utils.ids import generate_id

try:
    cognee = importlib.import_module("cognee")
except Exception:  # pragma: no cover - optional dep
    cognee = None


class CogneeBridge:
    """Adapter between cognee's ``DataPoint`` and PMD's ``MemoryNode``.

    The bridge does **not** monkey-patch cognee. It uses cognee's
    public API (``cognee.add``, ``cognee.cognify``) and emits PMD
    nodes alongside. The :meth:`wrap_datapoint` method is the single
    override point that adds PMD provenance to an existing cognee
    object.
    """

    def __init__(self, dag: ProvenanceDAG) -> None:
        self.dag = dag

    def wrap_datapoint(
        self,
        datapoint: Any,
        *,
        prompt_id: str | None = None,
        agent_id: str = "",
        parents: list[str] | None = None,
    ) -> MemoryNode:
        """Convert a cognee ``DataPoint`` into a PMD :class:`MemoryNode`.

        Reads ``datapoint.id``, ``datapoint.created_at``,
        ``datapoint.source_pipeline``, ``datapoint.source_task`` and
        mirrors them into PMD's prompt-level lineage fields. Returns
        the new node; the caller is expected to ``add_node`` it.
        """
        if cognee is None:  # pragma: no cover - import guard
            raise ImportError(
                "cognee is not installed; pip install cognee to use the bridge"
            )
        node = MemoryNode(
            id=str(getattr(datapoint, "id", generate_id())),
            content=str(getattr(datapoint, "name", "")),
            content_type=ContentType.STRUCTURED,
            structured_payload=getattr(datapoint, "metadata", None),
            creator_prompt_id=prompt_id or "",
            creator_agent_id=agent_id,
            creation_context={
                "source_pipeline": getattr(datapoint, "source_pipeline", None),
                "source_task": getattr(datapoint, "source_task", None),
                "source_user": getattr(datapoint, "source_user", None),
                "topological_rank": getattr(
                    datapoint, "topological_rank", None
                ),
            },
        )
        # Add the parents in a second pass so the node ID is stable.
        if parents:
            from pmd.core.node import CreatorEdge
            from pmd.core.enums import EdgeType

            edges = [
                CreatorEdge(
                    from_node_id=p, to_node_id=node.id, edge_type=EdgeType.DERIVED_FROM
                )
                for p in parents
            ]
            node = node.model_copy(update={"parents": edges})
        return node

    def ingest_text(
        self,
        text: str,
        *,
        agent_id: str = "",
        prompt: PromptContext | None = None,
    ) -> MemoryNode:
        """Add a plain-text memory that mirrors a cognee pipeline call.

        We do not actually invoke cognee's pipeline here — the
        integration is symmetric and a calling agent can drive cognee
        separately. The PMD side gets a node with the metadata of the
        call.
        """
        node = MemoryNode(
            id=generate_id(),
            content=text,
            content_type=ContentType.TEXT,
            creator_prompt_id=prompt.prompt_id if prompt else "",
            creator_agent_id=agent_id or (prompt.agent_id if prompt else ""),
            creation_context={
                "bridge": "cognee",
                "ingested_at": time.time(),
            },
        )
        return self.dag.add_node(node)


__all__ = ["CogneeBridge"]
