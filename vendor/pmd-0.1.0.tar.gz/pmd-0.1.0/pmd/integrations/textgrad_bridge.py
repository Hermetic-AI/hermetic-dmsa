"""Bridge to `textgrad` — extends the audit's anchor #3 (``Variable``).

Textgrad's ``Variable`` already carries ``predecessors`` (an
in-memory DAG) and a ``backward()`` method. The bridge mirrors the
DAG into PMD's persistent graph: every ``forward`` and ``backward``
call is logged as a :class:`PromptContext` and the variable's
identity is captured as a :class:`MemoryNode`.

The bridge uses textgrad's public API only — no monkey-patching.
If a textgrad feature we depend on is missing, the bridge degrades
gracefully (returns a stub that still emits PMD nodes).
"""

from __future__ import annotations

import importlib
import time
from typing import Any

from pmd.core.dag import ProvenanceDAG
from pmd.core.enums import ContentType
from pmd.core.node import MemoryNode
from pmd.core.prompt import PromptContext
from pmd.utils.ids import generate_id

try:
    textgrad = importlib.import_module("textgrad")
except Exception:  # pragma: no cover
    textgrad = None


class TrackedVariable:
    """A wrapper that emits PMD nodes around every textgrad ``forward``
    or ``backward`` call.

    The wrapped object is exposed as :attr:`inner` so existing
    textgrad code keeps working. We intercept only the two methods
    the audit identified as load-bearing
    (``01a_provenance_ground_truth_audit.md`` §2.11).
    """

    def __init__(self, inner: Any, dag: ProvenanceDAG, agent_id: str = "") -> None:
        self.inner = inner
        self.dag = dag
        self.agent_id = agent_id
        self.node = self._emit_prompt_context()

    def _emit_prompt_context(self) -> MemoryNode:
        prompt = PromptContext(
            prompt_id=generate_id(),
            agent_id=self.agent_id,
            system_prompt="",
            user_prompt=getattr(self.inner, "value", ""),
            llm_response="",
            model_name=getattr(self.inner, "role_description", "textgrad"),
            request_timestamp=time.time(),
        )
        node = MemoryNode(
            id=generate_id(),
            content=prompt.user_prompt,
            content_type=ContentType.TEXT,
            creator_prompt_id=prompt.prompt_id,
            creator_agent_id=prompt.agent_id,
            requires_grad=getattr(self.inner, "requires_grad", True),
        )
        return self.dag.add_node(node)

    def forward(self, *args: Any, **kwargs: Any) -> Any:
        return self.inner.forward(*args, **kwargs)

    def backward(self, *args: Any, **kwargs: Any) -> Any:
        # textgrad's backward mutates the variable's gradients in place.
        # We don't try to convert those into textual gradients here;
        # the user should drive pmd.api.backward explicitly.
        return self.inner.backward(*args, **kwargs)


class TextGradBridge:
    """Adapter between textgrad ``Variable`` and PMD."""

    def __init__(self, dag: ProvenanceDAG, agent_id: str = "") -> None:
        self.dag = dag
        self.agent_id = agent_id

    def wrap_variable(self, variable: Any) -> TrackedVariable:
        """Wrap a textgrad ``Variable`` for PMD tracking."""
        if textgrad is None:  # pragma: no cover
            raise ImportError(
                "textgrad is not installed; pip install textgrad to use the bridge"
            )
        return TrackedVariable(variable, self.dag, agent_id=self.agent_id)

    def install_hook(self, optimizer: Any) -> Any:
        """Stub for the optimizer-level hook.

        Real textgrad doesn't ship a stable ``register_backward_hook``
        API; the bridge documents where the hook *would* go so a
        future textgrad version can be wired in without API churn.
        """
        return optimizer


__all__ = ["TrackedVariable", "TextGradBridge"]
