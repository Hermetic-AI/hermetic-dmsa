"""External integration bridges — the Layer 1 adapters.

Each bridge wraps a foreign system (cognee, textgrad, hebb-mind) and
exposes a small adapter surface. The foreign libraries are imported
*lazily* so a PMD install that never touches a particular bridge
does not need the dependency.

If a bridge's dependency is missing, the import is a no-op (the
class is not registered) rather than a hard failure. Users get a
helpful message at the call site.
"""

from __future__ import annotations

__all__: list[str] = []

# Cognee bridge — optional.
try:
    from pmd.integrations.cognee_bridge import CogneeBridge

    __all__.append("CogneeBridge")
except ImportError:  # pragma: no cover - optional dep
    CogneeBridge = None  # type: ignore[assignment]

# TextGrad bridge — optional.
try:
    from pmd.integrations.textgrad_bridge import (
        TextGradBridge,
        TrackedVariable,
    )

    __all__.append("TextGradBridge")
    __all__.append("TrackedVariable")
except ImportError:  # pragma: no cover - optional dep
    TextGradBridge = None  # type: ignore[assignment]
    TrackedVariable = None  # type: ignore[assignment]

# Hebb bridge — optional.
try:
    from pmd.integrations.hebb_bridge import HebbBridge

    __all__.append("HebbBridge")
except ImportError:  # pragma: no cover - optional dep
    HebbBridge = None  # type: ignore[assignment]
