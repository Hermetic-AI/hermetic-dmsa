"""Bridge to `hebb-mind` — extends the audit's anchor #2 (flat `Memory`).

Hebb-mind's storage schema is a single ``memories`` table with a
free-form ``source`` string. The bridge converts each row into a
PMD node and records the lost consolidation edges so the audit
trail is queryable (the audit flagged consolidation as destroying
provenance — ``01a_provenance_ground_truth_audit.md`` §2.4).
"""

from __future__ import annotations

import importlib
import time
from typing import Any

from pmd.core.dag import ProvenanceDAG
from pmd.core.enums import ContentType, EdgeType
from pmd.core.node import CreatorEdge, MemoryNode
from pmd.utils.ids import generate_id

try:
    hebb = importlib.import_module("hebb")
except Exception:  # pragma: no cover
    hebb = None


class HebbBridge:
    """Adapter between hebb-mind's ``Memory`` rows and PMD's
    :class:`MemoryNode` records."""

    def __init__(self, dag: ProvenanceDAG) -> None:
        self.dag = dag

    def wrap_memory(
        self,
        memory: Any,
        *,
        partition_id: str = "",
    ) -> MemoryNode:
        """Convert a hebb ``Memory`` row into a PMD :class:`MemoryNode`.

        The ``importance_score`` field (default 5.0 in [0, 10]) is
        normalised to [0, 1]. The ``source`` field is preserved in
        ``creation_context["hebb_source"]``. A synthetic
        ``creator_prompt_id`` is computed from the hebb
        ``(partition_id, memory_id)`` tuple so existing data is
        queryable.
        """
        if hebb is None:  # pragma: no cover
            raise ImportError(
                "hebb-mind is not installed; pip install hebb-mind to use the bridge"
            )
        hebb_id = str(getattr(memory, "id", generate_id()))
        importance_raw = float(getattr(memory, "importance_score", 5.0))
        importance = max(0.0, min(1.0, importance_raw / 10.0))
        node = MemoryNode(
            id=hebb_id,
            content=str(getattr(memory, "content", "")),
            content_type=ContentType.TEXT,
            creator_prompt_id=f"hebb:{partition_id}:{hebb_id}",
            creator_agent_id="hebb-bridge",
            importance=importance,
            tags=list(getattr(memory, "tags", []) or []),
            creation_context={
                "hebb_source": getattr(memory, "source", None),
                "partition_id": partition_id,
                "importance_score_raw": importance_raw,
            },
        )
        return node

    def ingest_partition(
        self, partition_id: str, memories: list[Any]
    ) -> list[MemoryNode]:
        """Bulk-ingest a partition. Returns the new PMD nodes."""
        nodes: list[MemoryNode] = []
        for mem in memories:
            node = self.wrap_memory(mem, partition_id=partition_id)
            nodes.append(self.dag.add_node(node))
        return nodes

    def record_consolidation(
        self, old_ids: list[str], new_id: str
    ) -> None:
        """Record a ``CONSOLIDATED_FROM`` edge for each old -> new link.

        The audit flagged consolidation as destroying provenance. The
        bridge can only *record* what it is told; if the caller
        doesn't invoke this method, the edge is lost (and a
        ``warnings.warn`` is the bridge's default behaviour — see
        ``01b_pmd_architecture.md`` §10.3).
        """
        for old_id in old_ids:
            edge = CreatorEdge(
                from_node_id=old_id,
                to_node_id=new_id,
                edge_type=EdgeType.CONSOLIDATED_FROM,
                created_at=time.time(),
            )
            self.dag.add_edge(edge)


__all__ = ["HebbBridge"]
