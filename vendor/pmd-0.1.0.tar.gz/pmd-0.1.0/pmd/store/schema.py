"""SQLite DDL for the PMD store.

The DDL is the schema from the architecture document §8 verbatim,
with the indexes that give us sub-millisecond ancestor lookup
(``idx_nodes_creator_prompt``, ``idx_edges_to``, etc.). The DDL is
in its own module so it can be inspected, version-stamped, and
applied to a user-managed database file without booting the
:class:`SQLiteStore` class.
"""

from __future__ import annotations

# The DDL mirrors ``01b_pmd_architecture.md`` §8.1. We embed the
# payloads (node dicts, edge dicts) into the ``version_snapshots``
# table in this prototype; Phase 4 will externalise them to a separate
# file once snapshot sizes cross the GB threshold.
SCHEMA_DDL = """
CREATE TABLE IF NOT EXISTS memory_nodes (
    id                    TEXT PRIMARY KEY,
    version               INTEGER NOT NULL DEFAULT 1,
    content               TEXT NOT NULL,
    content_type          TEXT NOT NULL DEFAULT 'TEXT',
    embedding             BLOB,
    embedding_model       TEXT,
    structured_payload    TEXT,

    creator_prompt_id     TEXT NOT NULL,
    creator_agent_id      TEXT NOT NULL,
    creation_context      TEXT NOT NULL DEFAULT '{}',

    requires_grad         INTEGER NOT NULL DEFAULT 0,
    grad_learning_rate    REAL    NOT NULL DEFAULT 0.0,

    created_at            REAL NOT NULL,
    updated_at            REAL NOT NULL,
    last_accessed_at      REAL NOT NULL,
    access_count          INTEGER NOT NULL DEFAULT 0,
    ttl                   REAL,
    status                TEXT NOT NULL DEFAULT 'ACTIVE',
    checkpoint_id         TEXT,

    lineage_depth         INTEGER NOT NULL DEFAULT 0,
    importance            REAL NOT NULL DEFAULT 0.5,
    tags                  TEXT NOT NULL DEFAULT '[]',
    accumulated_feedback  TEXT NOT NULL DEFAULT '',
    feedback_count        INTEGER NOT NULL DEFAULT 0,
    last_feedback_at      REAL
);

CREATE TABLE IF NOT EXISTS creator_edges (
    from_node_id           TEXT NOT NULL,
    to_node_id             TEXT NOT NULL,
    edge_type              TEXT NOT NULL,
    weight                 REAL NOT NULL DEFAULT 1.0,
    confidence             REAL NOT NULL DEFAULT 1.0,
    metadata               TEXT NOT NULL DEFAULT '{}',
    created_at             REAL NOT NULL,
    feedback_text          TEXT NOT NULL DEFAULT '',
    feedback_token_cost    INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (from_node_id, to_node_id, edge_type),
    FOREIGN KEY (from_node_id) REFERENCES memory_nodes(id) ON DELETE CASCADE,
    FOREIGN KEY (to_node_id)   REFERENCES memory_nodes(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS prompt_contexts (
    prompt_id              TEXT PRIMARY KEY,
    agent_id               TEXT NOT NULL,
    parent_prompt_id       TEXT,
    system_prompt          TEXT NOT NULL DEFAULT '',
    user_prompt            TEXT NOT NULL DEFAULT '',
    llm_response           TEXT NOT NULL DEFAULT '',
    model_name             TEXT NOT NULL DEFAULT '',
    temperature            REAL NOT NULL DEFAULT 0.0,
    request_timestamp      REAL NOT NULL,
    response_timestamp     REAL,
    token_usage            TEXT NOT NULL DEFAULT '{}',
    success                INTEGER NOT NULL DEFAULT 1,
    error                  TEXT,
    tool_calls             TEXT NOT NULL DEFAULT '[]',
    retrieved_memory_ids   TEXT NOT NULL DEFAULT '[]',
    few_shot_memory_ids    TEXT NOT NULL DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS version_snapshots (
    version_id             TEXT PRIMARY KEY,
    parent_version_id      TEXT,
    created_at             REAL NOT NULL,
    dag_state_ref          TEXT NOT NULL,
    description            TEXT NOT NULL DEFAULT '',
    tag                    TEXT,
    node_count             INTEGER NOT NULL DEFAULT 0,
    edge_count             INTEGER NOT NULL DEFAULT 0,
    content_hash           TEXT NOT NULL DEFAULT '',
    payload_nodes          TEXT NOT NULL DEFAULT '{}',
    payload_edges          TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS backward_gradients (
    id                     INTEGER PRIMARY KEY AUTOINCREMENT,
    ancestor_node_id       TEXT NOT NULL,
    descendant_node_id     TEXT NOT NULL,
    edge_id                TEXT NOT NULL,
    gradient_text          TEXT NOT NULL,
    llm_used               TEXT NOT NULL,
    token_cost             INTEGER NOT NULL,
    feedback_source        TEXT NOT NULL,
    severity               REAL NOT NULL,
    created_at             REAL NOT NULL,
    FOREIGN KEY (ancestor_node_id)   REFERENCES memory_nodes(id) ON DELETE CASCADE,
    FOREIGN KEY (descendant_node_id) REFERENCES memory_nodes(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_nodes_creator_prompt
    ON memory_nodes(creator_prompt_id);
CREATE INDEX IF NOT EXISTS idx_nodes_creator_agent
    ON memory_nodes(creator_agent_id);
CREATE INDEX IF NOT EXISTS idx_nodes_status_created
    ON memory_nodes(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_nodes_requires_grad
    ON memory_nodes(requires_grad, grad_learning_rate);
CREATE INDEX IF NOT EXISTS idx_edges_to
    ON creator_edges(to_node_id, edge_type);
CREATE INDEX IF NOT EXISTS idx_edges_from
    ON creator_edges(from_node_id, edge_type);
CREATE INDEX IF NOT EXISTS idx_edges_type
    ON creator_edges(edge_type);
CREATE INDEX IF NOT EXISTS idx_prompts_agent
    ON prompt_contexts(agent_id, request_timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_versions_parent
    ON version_snapshots(parent_version_id);
CREATE INDEX IF NOT EXISTS idx_backward_ancestor
    ON backward_gradients(ancestor_node_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_backward_descendant
    ON backward_gradients(descendant_node_id, created_at DESC);
"""


def apply_schema(conn) -> None:
    """Apply the schema to an open ``sqlite3.Connection``.

    Provided for callers that want to initialise a database outside
    the :class:`SQLiteStore` class (e.g. for integration tests that
    share a single file across processes).
    """
    conn.executescript(SCHEMA_DDL)
    conn.commit()


__all__ = ["SCHEMA_DDL", "apply_schema"]
