"""Abstract storage interface.

A :class:`ProvenanceStore` is the contract that backends (in-memory,
SQLite, Neo4j) must implement. The DAG in :mod:`pmd.core.dag` only
ever sees this interface — there is no ``if isinstance(store, ...)``
branching in core code.
"""

from __future__ import annotations

from typing import Any, Iterator, Protocol, runtime_checkable

from pmd.core.node import CreatorEdge, MemoryNode
from pmd.core.prompt import PromptContext
from pmd.core.version import VersionSnapshot


@runtime_checkable
class ProvenanceStore(Protocol):
    """The contract every PMD storage backend must satisfy.

    Methods come in four families:

    1. Node CRUD: :meth:`put_node`, :meth:`get_node`, :meth:`list_nodes`.
    2. Edge CRUD: :meth:`put_edge`, :meth:`get_edge`,
       :meth:`list_edges`, :meth:`get_outgoing_edges`,
       :meth:`get_incoming_edges`.
    3. Prompt + gradient audit: :meth:`put_prompt_context`,
       :meth:`get_prompt_context`, :meth:`append_backward_gradient`,
       :meth:`list_backward_gradients`.
    4. Snapshots: :meth:`put_snapshot`, :meth:`get_snapshot`,
       :meth:`list_snapshots`, :meth:`load_snapshot_payload`.

    All methods must be **idempotent on ``put``** (writing the same
    record twice is a no-op) and must be **safe under concurrent
    callers** (the SQLite backend relies on WAL for this; the
    in-memory backend uses an :class:`threading.RLock`).
    """

    # ---- node CRUD --------------------------------------------------

    def put_node(self, node: MemoryNode) -> None: ...

    def get_node(self, node_id: str) -> MemoryNode | None: ...

    def list_nodes(self) -> Iterator[str]: ...

    # ---- edge CRUD --------------------------------------------------

    def put_edge(self, edge: CreatorEdge) -> None: ...

    def get_edge(
        self, from_id: str, to_id: str, edge_type: str
    ) -> CreatorEdge | None: ...

    def list_edges(self) -> Iterator[CreatorEdge]: ...

    def get_outgoing_edges(self, node_id: str) -> list[CreatorEdge]: ...

    def get_incoming_edges(self, node_id: str) -> list[CreatorEdge]: ...

    # ---- prompt contexts --------------------------------------------

    def put_prompt_context(self, prompt: PromptContext) -> None: ...

    def get_prompt_context(self, prompt_id: str) -> PromptContext | None: ...

    # ---- backward gradient audit log --------------------------------

    def append_backward_gradient(self, gradient: Any) -> None: ...

    def list_backward_gradients(
        self, node_id: str | None = None
    ) -> list[Any]: ...

    # ---- snapshots --------------------------------------------------

    def put_snapshot(
        self,
        snapshot: VersionSnapshot,
        nodes: dict[str, MemoryNode],
        edges: dict[tuple[str, str, str], CreatorEdge],
    ) -> None: ...

    def get_snapshot(self, version_id: str) -> VersionSnapshot | None: ...

    def list_snapshots(self) -> Iterator[VersionSnapshot]: ...

    def load_snapshot_payload(
        self, version_id: str
    ) -> tuple[dict[str, MemoryNode], dict[tuple[str, str, str], CreatorEdge]]: ...

    # ---- lineage traversal helpers (optional fast paths) ------------

    def get_ancestors(
        self,
        node_id: str,
        *,
        max_depth: int | None = None,
        edge_types: set[str] | None = None,
    ) -> list[str]: ...

    def get_descendants(
        self,
        node_id: str,
        *,
        max_depth: int | None = None,
        edge_types: set[str] | None = None,
    ) -> list[str]: ...

    # ---- housekeeping -----------------------------------------------

    def close(self) -> None: ...


__all__ = ["ProvenanceStore"]
