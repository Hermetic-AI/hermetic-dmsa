"""Storage layer — the Layer 5 abstraction.

PMD's :class:`~pmd.core.dag.ProvenanceDAG` is pure orchestration; the
source of truth lives in a :class:`ProvenanceStore`. The default
backend is :class:`InMemoryStore` (for tests and ephemeral agents) and
:class:`~pmd.store.sqlite_store.SQLiteStore` (for production).
"""

from __future__ import annotations

from pmd.store.base import ProvenanceStore
from pmd.store.memory_store import InMemoryStore

__all__ = ["ProvenanceStore", "InMemoryStore", "create_store"]


def create_store(backend: str = "memory", **kwargs: object) -> ProvenanceStore:
    """Factory for the registered backends.

    Args:
        backend: One of ``"memory"`` (default) or ``"sqlite"``.
            Unknown values raise :class:`pmd.errors.StorageError`.
        **kwargs: Forwarded to the backend's constructor. For
            ``"sqlite"``, this is typically ``path="..."``.
    """
    if backend == "memory":
        return InMemoryStore(**kwargs)
    if backend == "sqlite":
        # Local import to keep sqlite3 out of the cold path for
        # in-memory users.
        from pmd.store.sqlite_store import SQLiteStore

        return SQLiteStore(**kwargs)
    raise ValueError(
        f"unknown store backend {backend!r}; expected 'memory' or 'sqlite'"
    )
