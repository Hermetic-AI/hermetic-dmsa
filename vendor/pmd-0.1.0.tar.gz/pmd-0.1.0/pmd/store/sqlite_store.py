"""SQLite-backed :class:`ProvenanceStore` implementation.

The default durable backend. Configuration follows the architecture
document's §11.3:

- ``journal_mode=WAL`` — concurrent readers + one writer
- ``synchronous=NORMAL`` — safe with WAL; ~10x throughput vs FULL
- ``temp_store=MEMORY`` — temp tables live in RAM
- ``foreign_keys=ON`` — enforces referential integrity
- ``busy_timeout=5000`` — wait up to 5s for the writer lock

The connection is single-threaded (Python's GIL makes
``check_same_thread=False`` mostly safe; we still serialise writes via
a per-store lock). Phase 4 hardening will introduce a per-tenant
connection pool.

The DDL is in :mod:`pmd.store.schema` so the schema can be inspected
and applied to a user-managed database file separately from this
class.
"""

from __future__ import annotations

import json
import sqlite3
import struct
import threading
from typing import Any, Iterator

from pmd.core.enums import ContentType, EdgeType, NodeStatus
from pmd.core.node import CreatorEdge, MemoryNode
from pmd.core.prompt import PromptContext
from pmd.core.version import VersionSnapshot
from pmd.errors import StorageError
from pmd.store.schema import apply_schema


# ---------------------------------------------------------------------------
# (De)serialisation helpers
# ---------------------------------------------------------------------------


def _node_to_params(node: MemoryNode) -> dict[str, Any]:
    embedding_blob: bytes | None = None
    if node.embedding is not None:
        embedding_blob = struct.pack(f"<{len(node.embedding)}f", *node.embedding)
    return {
        "id": node.id,
        "version": node.version,
        "content": node.content,
        "content_type": node.content_type.value,
        "embedding": embedding_blob,
        "embedding_model": node.embedding_model,
        "structured_payload": json.dumps(node.structured_payload)
        if node.structured_payload is not None
        else None,
        "creator_prompt_id": node.creator_prompt_id,
        "creator_agent_id": node.creator_agent_id,
        "creation_context": json.dumps(node.creation_context, default=str),
        "requires_grad": int(node.requires_grad),
        "grad_learning_rate": node.grad_learning_rate,
        "created_at": node.created_at,
        "updated_at": node.updated_at,
        "last_accessed_at": node.last_accessed_at,
        "access_count": node.access_count,
        "ttl": node.ttl,
        "status": node.status.value,
        "checkpoint_id": node.checkpoint_id,
        "lineage_depth": node.lineage_depth,
        "importance": node.importance,
        "tags": json.dumps(node.tags),
        "accumulated_feedback": node.accumulated_feedback,
        "feedback_count": node.feedback_count,
        "last_feedback_at": node.last_feedback_at,
    }


def _row_to_node(row: sqlite3.Row) -> MemoryNode:
    embedding: list[float] | None = None
    if row["embedding"] is not None:
        n_floats = len(row["embedding"]) // 4
        embedding = list(struct.unpack(f"<{n_floats}f", row["embedding"]))
    structured_payload = (
        json.loads(row["structured_payload"]) if row["structured_payload"] else None
    )
    return MemoryNode(
        id=row["id"],
        version=row["version"],
        content=row["content"],
        content_type=ContentType(row["content_type"]),
        embedding=embedding,
        embedding_model=row["embedding_model"],
        structured_payload=structured_payload,
        creator_prompt_id=row["creator_prompt_id"],
        creator_agent_id=row["creator_agent_id"],
        creation_context=json.loads(row["creation_context"] or "{}"),
        requires_grad=bool(row["requires_grad"]),
        grad_learning_rate=row["grad_learning_rate"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        last_accessed_at=row["last_accessed_at"],
        access_count=row["access_count"],
        ttl=row["ttl"],
        status=NodeStatus(row["status"]),
        checkpoint_id=row["checkpoint_id"],
        lineage_depth=row["lineage_depth"],
        importance=row["importance"],
        tags=json.loads(row["tags"] or "[]"),
        accumulated_feedback=row["accumulated_feedback"],
        feedback_count=row["feedback_count"],
        last_feedback_at=row["last_feedback_at"],
    )


def _row_to_edge(row: sqlite3.Row) -> CreatorEdge:
    return CreatorEdge(
        from_node_id=row["from_node_id"],
        to_node_id=row["to_node_id"],
        edge_type=EdgeType(row["edge_type"]),
        weight=row["weight"],
        confidence=row["confidence"],
        metadata=json.loads(row["metadata"] or "{}"),
        created_at=row["created_at"],
        feedback_text=row["feedback_text"],
        feedback_token_cost=row["feedback_token_cost"],
    )


# ---------------------------------------------------------------------------
# The store
# ---------------------------------------------------------------------------


class SQLiteStore:
    """A single-file SQLite backend.

    Args:
        path: Filesystem path to the SQLite file. ``":memory:"`` opens
            a transient in-memory database (useful for tests).
    """

    def __init__(self, path: str = ":memory:") -> None:
        self._path = path
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(
            path,
            check_same_thread=False,
            detect_types=sqlite3.PARSE_DECLTYPES,
        )
        self._conn.row_factory = sqlite3.Row
        self._apply_pragmas()
        apply_schema(self._conn)

    def _apply_pragmas(self) -> None:
        """Apply WAL + busy_timeout + foreign_keys settings.

        ``execute`` does not accept multiple statements, so we run
        them one at a time. PRAGMA statements are idempotent.
        """
        pragmas = [
            "PRAGMA journal_mode = WAL",
            "PRAGMA synchronous = NORMAL",
            "PRAGMA temp_store = MEMORY",
            "PRAGMA mmap_size = 268435456",
            "PRAGMA cache_size = -64000",
            "PRAGMA foreign_keys = ON",
            "PRAGMA busy_timeout = 5000",
        ]
        with self._lock:
            cur = self._conn.cursor()
            for p in pragmas:
                cur.execute(p)
            self._conn.commit()

    # ---- node CRUD --------------------------------------------------

    def put_node(self, node: MemoryNode) -> None:
        with self._lock:
            self._conn.execute(
                """
                INSERT OR REPLACE INTO memory_nodes (
                    id, version, content, content_type, embedding,
                    embedding_model, structured_payload,
                    creator_prompt_id, creator_agent_id, creation_context,
                    requires_grad, grad_learning_rate,
                    created_at, updated_at, last_accessed_at, access_count,
                    ttl, status, checkpoint_id,
                    lineage_depth, importance, tags,
                    accumulated_feedback, feedback_count, last_feedback_at
                ) VALUES (
                    :id, :version, :content, :content_type, :embedding,
                    :embedding_model, :structured_payload,
                    :creator_prompt_id, :creator_agent_id, :creation_context,
                    :requires_grad, :grad_learning_rate,
                    :created_at, :updated_at, :last_accessed_at, :access_count,
                    :ttl, :status, :checkpoint_id,
                    :lineage_depth, :importance, :tags,
                    :accumulated_feedback, :feedback_count, :last_feedback_at
                )
                """,
                _node_to_params(node),
            )
            self._conn.commit()

    def get_node(self, node_id: str) -> MemoryNode | None:
        with self._lock:
            cur = self._conn.execute(
                "SELECT * FROM memory_nodes WHERE id = ?", (node_id,)
            )
            row = cur.fetchone()
            return _row_to_node(row) if row else None

    def list_nodes(self) -> Iterator[str]:
        with self._lock:
            cur = self._conn.execute("SELECT id FROM memory_nodes")
            for row in cur:
                yield row["id"]

    # ---- edge CRUD --------------------------------------------------

    def put_edge(self, edge: CreatorEdge) -> None:
        with self._lock:
            self._conn.execute(
                """
                INSERT OR REPLACE INTO creator_edges (
                    from_node_id, to_node_id, edge_type, weight, confidence,
                    metadata, created_at, feedback_text, feedback_token_cost
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    edge.from_node_id,
                    edge.to_node_id,
                    edge.edge_type.value,
                    edge.weight,
                    edge.confidence,
                    json.dumps(edge.metadata, default=str),
                    edge.created_at,
                    edge.feedback_text,
                    edge.feedback_token_cost,
                ),
            )
            self._conn.commit()

    def get_edge(
        self, from_id: str, to_id: str, edge_type: str
    ) -> CreatorEdge | None:
        with self._lock:
            cur = self._conn.execute(
                """
                SELECT * FROM creator_edges
                WHERE from_node_id = ? AND to_node_id = ? AND edge_type = ?
                """,
                (from_id, to_id, edge_type),
            )
            row = cur.fetchone()
            return _row_to_edge(row) if row else None

    def list_edges(self) -> Iterator[CreatorEdge]:
        with self._lock:
            cur = self._conn.execute("SELECT * FROM creator_edges")
            for row in cur:
                yield _row_to_edge(row)

    def get_outgoing_edges(self, node_id: str) -> list[CreatorEdge]:
        with self._lock:
            cur = self._conn.execute(
                "SELECT * FROM creator_edges WHERE from_node_id = ?",
                (node_id,),
            )
            return [_row_to_edge(r) for r in cur]

    def get_incoming_edges(self, node_id: str) -> list[CreatorEdge]:
        with self._lock:
            cur = self._conn.execute(
                "SELECT * FROM creator_edges WHERE to_node_id = ?",
                (node_id,),
            )
            return [_row_to_edge(r) for r in cur]

    # ---- prompt contexts --------------------------------------------

    def put_prompt_context(self, prompt: PromptContext) -> None:
        with self._lock:
            self._conn.execute(
                """
                INSERT OR REPLACE INTO prompt_contexts (
                    prompt_id, agent_id, parent_prompt_id,
                    system_prompt, user_prompt, llm_response, model_name,
                    temperature, request_timestamp, response_timestamp,
                    token_usage, success, error,
                    tool_calls, retrieved_memory_ids, few_shot_memory_ids
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    prompt.prompt_id,
                    prompt.agent_id,
                    prompt.parent_prompt_id,
                    prompt.system_prompt,
                    prompt.user_prompt,
                    prompt.llm_response,
                    prompt.model_name,
                    prompt.temperature,
                    prompt.request_timestamp,
                    prompt.response_timestamp,
                    json.dumps(prompt.token_usage),
                    int(prompt.success),
                    prompt.error,
                    json.dumps(prompt.tool_calls, default=str),
                    json.dumps(prompt.retrieved_memory_ids),
                    json.dumps(prompt.few_shot_memory_ids),
                ),
            )
            self._conn.commit()

    def get_prompt_context(self, prompt_id: str) -> PromptContext | None:
        with self._lock:
            cur = self._conn.execute(
                "SELECT * FROM prompt_contexts WHERE prompt_id = ?", (prompt_id,)
            )
            row = cur.fetchone()
            if row is None:
                return None
            return PromptContext(
                prompt_id=row["prompt_id"],
                agent_id=row["agent_id"],
                parent_prompt_id=row["parent_prompt_id"],
                system_prompt=row["system_prompt"],
                user_prompt=row["user_prompt"],
                llm_response=row["llm_response"],
                model_name=row["model_name"],
                temperature=row["temperature"],
                request_timestamp=row["request_timestamp"],
                response_timestamp=row["response_timestamp"],
                token_usage=json.loads(row["token_usage"] or "{}"),
                success=bool(row["success"]),
                error=row["error"],
                tool_calls=json.loads(row["tool_calls"] or "[]"),
                retrieved_memory_ids=json.loads(
                    row["retrieved_memory_ids"] or "[]"
                ),
                few_shot_memory_ids=json.loads(
                    row["few_shot_memory_ids"] or "[]"
                ),
            )

    # ---- backward gradient audit log --------------------------------

    def append_backward_gradient(self, gradient: Any) -> None:
        with self._lock:
            self._conn.execute(
                """
                INSERT INTO backward_gradients (
                    ancestor_node_id, descendant_node_id, edge_id,
                    gradient_text, llm_used, token_cost,
                    feedback_source, severity, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    getattr(gradient, "ancestor_node_id", ""),
                    getattr(gradient, "descendant_node_id", ""),
                    getattr(
                        getattr(gradient, "edge", None), "edge_key", lambda: ""
                    )(),
                    getattr(gradient, "gradient_text", ""),
                    getattr(gradient, "llm_used", ""),
                    getattr(gradient, "token_cost", 0),
                    getattr(gradient, "feedback_source", "USER"),
                    getattr(gradient, "severity", 1.0),
                    getattr(gradient, "created_at", 0.0),
                ),
            )
            self._conn.commit()

    def list_backward_gradients(
        self, node_id: str | None = None
    ) -> list[Any]:
        with self._lock:
            if node_id is None:
                cur = self._conn.execute(
                    "SELECT * FROM backward_gradients ORDER BY id DESC"
                )
            else:
                cur = self._conn.execute(
                    """
                    SELECT * FROM backward_gradients
                    WHERE ancestor_node_id = ? OR descendant_node_id = ?
                    ORDER BY id DESC
                    """,
                    (node_id, node_id),
                )
            return [dict(r) for r in cur]

    # ---- snapshots --------------------------------------------------

    def put_snapshot(
        self,
        snapshot: VersionSnapshot,
        nodes: dict[str, MemoryNode],
        edges: dict[tuple[str, str, str], CreatorEdge],
    ) -> None:
        with self._lock:
            payload_nodes = {
                nid: n.model_dump(mode="json") for nid, n in nodes.items()
            }
            payload_edges = {
                f"{f}|{t}|{et}": e.model_dump(mode="json")
                for (f, t, et), e in edges.items()
            }
            self._conn.execute(
                """
                INSERT OR REPLACE INTO version_snapshots (
                    version_id, parent_version_id, created_at, dag_state_ref,
                    description, tag, node_count, edge_count, content_hash,
                    payload_nodes, payload_edges
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    snapshot.version_id,
                    snapshot.parent_version_id,
                    snapshot.created_at,
                    snapshot.dag_state_ref,
                    snapshot.description,
                    snapshot.tag,
                    snapshot.node_count,
                    snapshot.edge_count,
                    snapshot.content_hash,
                    json.dumps(payload_nodes, default=str),
                    json.dumps(payload_edges, default=str),
                ),
            )
            self._conn.commit()

    def get_snapshot(self, version_id: str) -> VersionSnapshot | None:
        with self._lock:
            cur = self._conn.execute(
                "SELECT * FROM version_snapshots WHERE version_id = ?",
                (version_id,),
            )
            row = cur.fetchone()
            if row is None:
                return None
            return VersionSnapshot(
                version_id=row["version_id"],
                parent_version_id=row["parent_version_id"],
                created_at=row["created_at"],
                dag_state_ref=row["dag_state_ref"],
                description=row["description"],
                tag=row["tag"],
                node_count=row["node_count"],
                edge_count=row["edge_count"],
                content_hash=row["content_hash"],
            )

    def list_snapshots(self) -> Iterator[VersionSnapshot]:
        with self._lock:
            cur = self._conn.execute(
                "SELECT * FROM version_snapshots ORDER BY created_at"
            )
            for row in cur:
                yield self.get_snapshot(row["version_id"])  # type: ignore[misc]

    def load_snapshot_payload(
        self, version_id: str
    ) -> tuple[dict[str, MemoryNode], dict[tuple[str, str, str], CreatorEdge]]:
        with self._lock:
            cur = self._conn.execute(
                "SELECT payload_nodes, payload_edges FROM version_snapshots "
                "WHERE version_id = ?",
                (version_id,),
            )
            row = cur.fetchone()
            if row is None:
                raise StorageError(
                    f"snapshot {version_id!r} not found",
                    details={"version_id": version_id},
                )
            raw_nodes = json.loads(row["payload_nodes"] or "{}")
            raw_edges = json.loads(row["payload_edges"] or "{}")
            nodes = {
                nid: MemoryNode.model_validate(d) for nid, d in raw_nodes.items()
            }
            edges: dict[tuple[str, str, str], CreatorEdge] = {}
            for key, d in raw_edges.items():
                edge = CreatorEdge.model_validate(d)
                edges[edge.edge_key()] = edge
            return nodes, edges

    # ---- lineage traversal helpers ---------------------------------

    def _walk_cte(
        self,
        *,
        start: str,
        direction: str,
        max_depth: int,
        edge_types: set[str] | None,
    ) -> list[str]:
        """Generic BFS-via-CTE helper.

        ``direction="up"`` walks via ``to_node_id`` -> ``from_node_id``;
        ``direction="down"`` walks the other way. The recursive CTE
        is identical in both cases modulo the join direction.
        """
        if direction == "up":
            anchor_col, step_col = "from_node_id", "to_node_id"
            join_col, next_col = "to_node_id", "from_node_id"
        else:
            anchor_col, step_col = "to_node_id", "from_node_id"
            join_col, next_col = "from_node_id", "to_node_id"
        if edge_types:
            placeholders = ",".join("?" for _ in edge_types)
            type_clause_initial = (
                f"AND {step_col} IN ({placeholders})"  # not used for first col
            )
            type_clause = f"AND e.{step_col} IN ({placeholders})"
        else:
            type_clause_initial = ""
            type_clause = ""
        with self._lock:
            params: list[Any] = [start]
            if edge_types:
                # We don't actually need the initial filter on edge_type
                # for the anchor row (we anchor by node id), but the
                # step recursion does need it.
                pass
            cur = self._conn.execute(
                f"""
                WITH RECURSIVE walk(id, depth) AS (
                    SELECT {anchor_col}, 1
                    FROM creator_edges
                    WHERE {join_col} = ?
                    UNION ALL
                    SELECT e.{next_col}, w.depth + 1
                    FROM creator_edges e
                    JOIN walk w ON e.{join_col} = w.id
                    WHERE w.depth < ? {type_clause}
                )
                SELECT DISTINCT id FROM walk
                """,
                (start, max_depth, *(edge_types or [])),
            )
            return [row["id"] for row in cur]

    def get_ancestors(
        self,
        node_id: str,
        *,
        max_depth: int | None = None,
        edge_types: set[str] | None = None,
    ) -> list[str]:
        return self._walk_cte(
            start=node_id,
            direction="up",
            max_depth=50 if max_depth is None else max_depth,
            edge_types=edge_types,
        )

    def get_descendants(
        self,
        node_id: str,
        *,
        max_depth: int | None = None,
        edge_types: set[str] | None = None,
    ) -> list[str]:
        return self._walk_cte(
            start=node_id,
            direction="down",
            max_depth=50 if max_depth is None else max_depth,
            edge_types=edge_types,
        )

    # ---- housekeeping -----------------------------------------------

    def vacuum(self) -> None:
        """Run ``VACUUM`` to reclaim space. Locks the database file."""
        with self._lock:
            self._conn.execute("VACUUM")

    def integrity_check(self) -> list[str]:
        """Return a list of integrity issues (empty list = healthy)."""
        with self._lock:
            cur = self._conn.execute("PRAGMA integrity_check")
            return [row[0] for row in cur]

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def __contains__(self, node_id: object) -> bool:
        if not isinstance(node_id, str):
            return False
        with self._lock:
            cur = self._conn.execute(
                "SELECT 1 FROM memory_nodes WHERE id = ?", (node_id,)
            )
            return cur.fetchone() is not None

    def __len__(self) -> int:
        with self._lock:
            cur = self._conn.execute("SELECT COUNT(*) AS n FROM memory_nodes")
            return int(cur.fetchone()["n"])


__all__ = ["SQLiteStore"]
