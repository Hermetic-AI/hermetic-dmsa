"""In-memory :class:`ProvenanceStore` implementation.

Used by the example, the test suite, and any caller that does not
need durability. The store is thread-safe via a single
:class:`threading.RLock`; reads are concurrent under the GIL because
CPython dict operations are atomic.
"""

from __future__ import annotations

import threading
from collections import defaultdict, deque
from typing import Any, Iterator

from pmd.core.node import CreatorEdge, MemoryNode
from pmd.core.prompt import PromptContext
from pmd.core.version import VersionSnapshot
from pmd.errors import StorageError


class InMemoryStore:
    """Thread-safe in-memory backend.

    A single :class:`threading.RLock` serialises mutations. Reads
    acquire the lock too, but they're fast (dict lookups) and don't
    contend with each other in practice.

    Snapshots are stored as deep-copied dicts so a later mutation
    cannot affect a previously snapshotted version. This is
    important for the ``rollback`` correctness story.
    """

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._nodes: dict[str, MemoryNode] = {}
        self._edges: dict[tuple[str, str, str], CreatorEdge] = {}
        self._prompts: dict[str, PromptContext] = {}
        self._gradients: list[Any] = []
        self._snapshots: dict[str, VersionSnapshot] = {}
        self._snapshot_nodes: dict[str, dict[str, MemoryNode]] = {}
        self._snapshot_edges: dict[
            str, dict[tuple[str, str, str], CreatorEdge]
        ] = {}

    # ---- node CRUD --------------------------------------------------

    def put_node(self, node: MemoryNode) -> None:
        with self._lock:
            self._nodes[node.id] = node

    def get_node(self, node_id: str) -> MemoryNode | None:
        with self._lock:
            return self._nodes.get(node_id)

    def list_nodes(self) -> Iterator[str]:
        with self._lock:
            # Return a copy of the keys to avoid mutation during
            # iteration. Callers should not rely on the iterator
            # being live.
            return iter(list(self._nodes.keys()))

    # ---- edge CRUD --------------------------------------------------

    def put_edge(self, edge: CreatorEdge) -> None:
        with self._lock:
            self._edges[edge.edge_key()] = edge

    def get_edge(
        self, from_id: str, to_id: str, edge_type: str
    ) -> CreatorEdge | None:
        with self._lock:
            return self._edges.get((from_id, to_id, edge_type))

    def list_edges(self) -> Iterator[CreatorEdge]:
        with self._lock:
            return iter(list(self._edges.values()))

    def get_outgoing_edges(self, node_id: str) -> list[CreatorEdge]:
        with self._lock:
            return [e for e in self._edges.values() if e.from_node_id == node_id]

    def get_incoming_edges(self, node_id: str) -> list[CreatorEdge]:
        with self._lock:
            return [e for e in self._edges.values() if e.to_node_id == node_id]

    # ---- prompt contexts --------------------------------------------

    def put_prompt_context(self, prompt: PromptContext) -> None:
        with self._lock:
            self._prompts[prompt.prompt_id] = prompt

    def get_prompt_context(self, prompt_id: str) -> PromptContext | None:
        with self._lock:
            return self._prompts.get(prompt_id)

    # ---- backward gradient audit log --------------------------------

    def append_backward_gradient(self, gradient: Any) -> None:
        with self._lock:
            self._gradients.append(gradient)

    def list_backward_gradients(
        self, node_id: str | None = None
    ) -> list[Any]:
        with self._lock:
            if node_id is None:
                return list(self._gradients)
            return [
                g
                for g in self._gradients
                if getattr(g, "ancestor_node_id", None) == node_id
                or getattr(g, "descendant_node_id", None) == node_id
            ]

    # ---- snapshots --------------------------------------------------

    def put_snapshot(
        self,
        snapshot: VersionSnapshot,
        nodes: dict[str, MemoryNode],
        edges: dict[tuple[str, str, str], CreatorEdge],
    ) -> None:
        with self._lock:
            self._snapshots[snapshot.version_id] = snapshot
            # Deep-copy the payloads so subsequent mutations do not
            # affect the snapshot.
            self._snapshot_nodes[snapshot.version_id] = {
                nid: n.model_copy() for nid, n in nodes.items()
            }
            self._snapshot_edges[snapshot.version_id] = {
                k: e.model_copy() for k, e in edges.items()
            }

    def get_snapshot(self, version_id: str) -> VersionSnapshot | None:
        with self._lock:
            return self._snapshots.get(version_id)

    def list_snapshots(self) -> Iterator[VersionSnapshot]:
        with self._lock:
            return iter(list(self._snapshots.values()))

    def load_snapshot_payload(
        self, version_id: str
    ) -> tuple[dict[str, MemoryNode], dict[tuple[str, str, str], CreatorEdge]]:
        with self._lock:
            nodes = self._snapshot_nodes.get(version_id)
            edges = self._snapshot_edges.get(version_id)
            if nodes is None or edges is None:
                raise StorageError(
                    f"snapshot {version_id!r} not found",
                    details={"version_id": version_id},
                )
            return nodes, edges

    # ---- lineage traversal helpers ---------------------------------

    def get_ancestors(
        self,
        node_id: str,
        *,
        max_depth: int | None = None,
        edge_types: set[str] | None = None,
    ) -> list[str]:
        """BFS via the adjacency index, returning ancestor IDs only.

        The DAG layer uses this for the lineage-aware retrieval seed
        expansion. The implementation is the same as the DAG's
        in-memory BFS, but expressed against the store to give backends
        (e.g. Neo4j) a chance to do it server-side via Cypher.
        """
        with self._lock:
            if node_id not in self._nodes:
                return []
            types = edge_types
            seen: set[str] = {node_id}
            results: list[str] = []
            frontier: deque[tuple[str, int]] = deque([(node_id, 0)])
            # Build a parent index on the fly. The cost is O(E) and
            # the result is cached for the lifetime of this call.
            parent_index: dict[str, list[str]] = defaultdict(list)
            for e in self._edges.values():
                if types is None or e.edge_type.value in types:
                    parent_index[e.to_node_id].append(e.from_node_id)
            while frontier:
                current, d = frontier.popleft()
                if max_depth is not None and d >= max_depth:
                    continue
                for parent in parent_index.get(current, ()):
                    if parent in seen:
                        continue
                    seen.add(parent)
                    results.append(parent)
                    frontier.append((parent, d + 1))
            return results

    def get_descendants(
        self,
        node_id: str,
        *,
        max_depth: int | None = None,
        edge_types: set[str] | None = None,
    ) -> list[str]:
        with self._lock:
            if node_id not in self._nodes:
                return []
            types = edge_types
            seen: set[str] = {node_id}
            results: list[str] = []
            frontier: deque[tuple[str, int]] = deque([(node_id, 0)])
            child_index: dict[str, list[str]] = defaultdict(list)
            for e in self._edges.values():
                if types is None or e.edge_type.value in types:
                    child_index[e.from_node_id].append(e.to_node_id)
            while frontier:
                current, d = frontier.popleft()
                if max_depth is not None and d >= max_depth:
                    continue
                for child in child_index.get(current, ()):
                    if child in seen:
                        continue
                    seen.add(child)
                    results.append(child)
                    frontier.append((child, d + 1))
            return results

    # ---- housekeeping -----------------------------------------------

    def close(self) -> None:
        # Nothing to do for the in-memory backend. Provided for
        # symmetry with the SQLite backend.
        return None

    def __contains__(self, node_id: object) -> bool:
        return isinstance(node_id, str) and node_id in self._nodes

    def __len__(self) -> int:
        return len(self._nodes)


__all__ = ["InMemoryStore"]
