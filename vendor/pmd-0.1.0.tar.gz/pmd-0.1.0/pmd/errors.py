"""Closed hierarchy of PMD exception types.

Every exception raised by PMD itself derives from :class:`PMDError`, so a
caller can do::

    try:
        pmd.add_memory(...)
    except PMDError:
        # handle every library failure uniformly
        ...

Each concrete class also carries an error code (e.g. ``PMD-3000``) so logs
and metrics can be filtered without parsing the message text. The mapping
mirrors ``01b_pmd_architecture.md`` §12.
"""

from __future__ import annotations

from typing import Any


class PMDError(Exception):
    """Base class for all PMD errors. Carries a stable error code.

    Args:
        message: Human-readable description of the failure.
        code: Stable error code such as ``PMD-3000``. The default is
            ``PMD-1000`` (the base code).
        details: Optional machine-readable payload, surfaced in logs and
            serialised into the audit trail.
    """

    DEFAULT_CODE = "PMD-1000"

    def __init__(
        self,
        message: str = "",
        *,
        code: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code = code or self.DEFAULT_CODE
        self.details: dict[str, Any] = dict(details or {})

    def __str__(self) -> str:  # pragma: no cover - cosmetic
        suffix = f" [code={self.code}]"
        return f"{self.message}{suffix}" if self.message else self.code


class StorageError(PMDError):
    """The underlying store (SQLite, Neo4j, in-memory) raised an error."""

    DEFAULT_CODE = "PMD-2000"


class DiskFullError(StorageError):
    """SQLite (or OS) reported the volume as full."""

    DEFAULT_CODE = "PMD-2100"


class DAGInconsistencyError(PMDError):
    """The DAG would be left in an invalid state if the operation proceeded.

    Subclasses correspond to the four concrete failure modes defined in
    ``01b_pmd_architecture.md`` §12.
    """

    DEFAULT_CODE = "PMD-3000"


class CycleDetectedError(DAGInconsistencyError):
    """An ``add_edge`` call would close a cycle."""

    DEFAULT_CODE = "PMD-3000"


class MissingParentError(DAGInconsistencyError):
    """An ``add_edge`` references a node that does not exist."""

    DEFAULT_CODE = "PMD-3001"


class DanglingEdgeError(DAGInconsistencyError):
    """An edge references a node that has been deleted."""

    DEFAULT_CODE = "PMD-3002"


class DuplicateEdgeError(DAGInconsistencyError):
    """The (from, to, edge_type) primary key is already present."""

    DEFAULT_CODE = "PMD-3003"


class BackwardPropagationError(PMDError):
    """A backward pass failed (LLM error, missing ancestor, malformed gradient)."""

    DEFAULT_CODE = "PMD-4000"


class VersionConflictError(PMDError):
    """A ``rollback`` or ``snapshot`` would clobber uncommitted state."""

    DEFAULT_CODE = "PMD-5000"


class LineageNotFoundError(PMDError):
    """A lineage query targeted a node that does not exist."""

    DEFAULT_CODE = "PMD-6000"


class RequiresGradViolationError(PMDError):
    """A backward pass tried to update a node with ``requires_grad=False``."""

    DEFAULT_CODE = "PMD-7000"


class EmbeddingError(PMDError):
    """An embedder backend (Sentence-Transformers, OpenAI, hash-based stub) failed."""

    DEFAULT_CODE = "PMD-8000"


__all__ = [
    "PMDError",
    "StorageError",
    "DiskFullError",
    "DAGInconsistencyError",
    "CycleDetectedError",
    "MissingParentError",
    "DanglingEdgeError",
    "DuplicateEdgeError",
    "BackwardPropagationError",
    "VersionConflictError",
    "LineageNotFoundError",
    "RequiresGradViolationError",
    "EmbeddingError",
]
