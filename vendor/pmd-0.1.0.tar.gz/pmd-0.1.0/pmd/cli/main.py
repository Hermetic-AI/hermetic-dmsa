"""Console-script entry point shim.

The ``pmd`` console script (configured in ``pyproject.toml``) calls
``pmd.cli:main``. We keep the implementation in
``pmd/cli/__init__.py`` so the package can also be imported
directly; this module is just a re-export for the script wrapper.
"""

from __future__ import annotations

from pmd.cli import main

if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
