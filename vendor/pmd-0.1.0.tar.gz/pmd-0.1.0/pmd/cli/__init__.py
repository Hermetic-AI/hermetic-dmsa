"""PMD CLI — a thin ``argparse``-based entry point.

The CLI exposes the most common operations (``snapshot``, ``rollback``,
``export-dot``) for scripting. It is *not* a full REPL; for that,
open a Python prompt and ``import pmd``.
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Sequence

from pmd import ProvenanceDAG
from pmd.store import create_store


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pmd",
        description="Provenance-aware Memory DAG CLI",
    )
    parser.add_argument(
        "--store",
        choices=("memory", "sqlite"),
        default="memory",
        help="Storage backend (default: memory)",
    )
    parser.add_argument(
        "--path",
        default=":memory:",
        help="Path to the SQLite database (only with --store=sqlite)",
    )

    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("info", help="Print DAG statistics")
    sub.add_parser("export-dot", help="Write Graphviz DOT to stdout")
    sub.add_parser("export-json", help="Write JSON to stdout")
    sub.add_parser("vacuum", help="Run SQLite VACUUM (no-op for memory)")
    sub.add_parser(
        "integrity-check",
        help="Run SQLite integrity_check (no-op for memory)",
    )

    snap = sub.add_parser("snapshot", help="Snapshot the current DAG")
    snap.add_argument("--description", default="manual snapshot")

    rb = sub.add_parser("rollback", help="Rollback to a prior snapshot")
    rb.add_argument("version_id")

    diff = sub.add_parser("diff", help="Diff two snapshots")
    diff.add_argument("v1")
    diff.add_argument("v2")

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    store = create_store(args.store, path=args.path)
    dag = ProvenanceDAG(store=store)

    if args.command == "info":
        print(json.dumps({"nodes": len(dag)}, indent=2))
        return 0
    if args.command == "export-dot":
        sys.stdout.write(dag.export_dot())
        return 0
    if args.command == "export-json":
        sys.stdout.write(json.dumps(dag.export_json(), indent=2))
        return 0
    if args.command == "snapshot":
        snap = dag.snapshot(description=args.description)
        print(snap.version_id)
        return 0
    if args.command == "rollback":
        dag.rollback(args.version_id)
        print(f"rolled back to {args.version_id}")
        return 0
    if args.command == "diff":
        diff = dag.diff(args.v1, args.v2)
        print(diff.summary)
        return 0
    if args.command == "vacuum":
        vacuum = getattr(store, "vacuum", None)
        if callable(vacuum):
            vacuum()
        return 0
    if args.command == "integrity-check":
        check = getattr(store, "integrity_check", None)
        if callable(check):
            issues = check()
            print(json.dumps(issues, indent=2))
            return 0 if not issues else 1
        return 0

    parser.print_help()
    return 1


__all__ = ["main"]
