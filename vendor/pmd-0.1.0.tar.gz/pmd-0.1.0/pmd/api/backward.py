"""Backward pass — the public entry point for textual derivatives.

This module implements the §7 algorithm. The default deriver is a
deterministic stub (no LLM calls). Real LLM-backed derivers
(``LLMBackwardDeriver``) accept an injectable ``LLMClient`` Protocol
so tests can pass a mock.

Caching: gradient text is content-hashed by
``(ancestor_id, descendant_id, feedback_text)``. Repeat calls with
the same hash return the cached gradient without a new LLM call.
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Protocol, runtime_checkable

from pmd.core.dag import ProvenanceDAG
from pmd.core.enums import FeedbackSource, PropagationStrategy
from pmd.core.node import CreatorEdge
from pmd.errors import BackwardPropagationError


# ---------- value types -----------------------------------------------------


@dataclass(frozen=True)
class BackwardFeedback:
    """Input to :func:`backward`.

    Attributes:
        target_node_id: The leaf node to backprop from.
        feedback_text: The textual signal.
        source: Where the signal came from.
        severity: Scales the textual derivative. ``[0, 1]``.
        propagation_strategy: See :class:`PropagationStrategy`.
        max_depth: Hard cap on the number of ancestors visited.
        extra_context: Caller-defined data merged into the prompt.
    """

    target_node_id: str
    feedback_text: str
    source: FeedbackSource = FeedbackSource.USER
    severity: float = 1.0
    propagation_strategy: PropagationStrategy = (
        PropagationStrategy.STOP_AT_GRAD_BOUNDARY
    )
    max_depth: int = 50
    extra_context: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class BackwardGradient:
    """Output of :func:`backward` — one per trainable ancestor.

    The dataclass mirrors the architecture document's §4.7 spec. We
    keep it as a dataclass (not Pydantic) because it is constructed
    inside the backward loop and never round-trips through the store.
    """

    edge: CreatorEdge | None
    gradient_text: str
    llm_used: str
    token_cost: int
    ancestor_node_id: str
    descendant_node_id: str
    feedback_source: str = FeedbackSource.USER.value
    severity: float = 1.0
    created_at: float = field(default_factory=time.time)


# ---------- deriver interface ----------------------------------------------


@runtime_checkable
class LLMClient(Protocol):
    """The minimum surface area of an LLM client.

    A real implementation might be a thin wrapper around the OpenAI,
    Anthropic, or a local vLLM endpoint. The protocol keeps tests
    cheap: pass a function that returns the canned response.
    """

    def __call__(self, prompt: str) -> tuple[str, int]: ...
    """Return ``(response_text, total_token_count)``."""


@runtime_checkable
class BackwardDeriver(Protocol):
    """Pluggable textual-derivative operator."""

    name: str

    def derive(self, prompt: str) -> tuple[str, str, int]:
        """Return ``(gradient_text, model_name, token_cost)``."""


# ---------- default deriver -----------------------------------------------


class StaticBackwardDeriver:
    """A deriver that returns a fixed text. No LLM call.

    Used in tests and when the caller wants to inspect the backward
    pass *structure* (which ancestors get visited, in which order)
    without paying for an LLM call.
    """

    name = "static"

    def __init__(self, response: str = "[static-derivative]") -> None:
        self._response = response

    def derive(self, prompt: str) -> tuple[str, str, int]:
        return self._response, "static", len(prompt) // 4


class LLMBackwardDeriver:
    """Default LLM-backed deriver.

    The actual LLM call is delegated to a ``LLMClient`` so tests can
    substitute a mock. The default client is a deterministic stub
    (hash of the prompt) — keeps the library runnable without an API
    key while exercising the full wiring.
    """

    name = "llm"

    def __init__(
        self,
        model: str = "gpt-4o",
        llm_client: LLMClient | None = None,
    ) -> None:
        self._model = model
        self._client = llm_client or _hash_stub_client(model)

    def derive(self, prompt: str) -> tuple[str, str, int]:
        try:
            response_text, token_cost = self._client(prompt)
        except Exception as exc:  # pragma: no cover - external failure
            raise BackwardPropagationError(
                f"LLM call failed: {exc}", details={"model": self._model}
            ) from exc
        return response_text, self._model, int(token_cost)


def _hash_stub_client(model: str) -> LLMClient:
    """Default LLM client: hashes the prompt to a deterministic string.

    This exists so the example and the tests run without any external
    service. The hash is a 16-char hex prefix of SHA-256.
    """

    def client(prompt: str) -> tuple[str, int]:
        digest = hashlib.sha256(prompt.encode("utf-8")).hexdigest()[:16]
        text = f"[{model}-derivative-{digest}] {prompt[:80]}"
        # Rough token estimate: 1 token ≈ 4 chars.
        return text, max(1, len(prompt) // 4)

    return client  # type: ignore[return-value]


# ---------- cache -----------------------------------------------------------


class _GradientCache:
    """A tiny LRU keyed by ``(ancestor_id, descendant_id, feedback_hash)``.

    Bounded size (default 1024) so it cannot grow unboundedly under a
    long-running agent.
    """

    def __init__(self, max_size: int = 1024) -> None:
        self._max = max_size
        self._data: dict[tuple[str, str, str], BackwardGradient] = {}
        self._order: list[tuple[str, str, str]] = []

    def get(self, key: tuple[str, str, str]) -> BackwardGradient | None:
        if key not in self._data:
            return None
        # Refresh LRU order.
        self._order.remove(key)
        self._order.append(key)
        return self._data[key]

    def put(self, key: tuple[str, str, str], value: BackwardGradient) -> None:
        if key in self._data:
            self._order.remove(key)
        self._data[key] = value
        self._order.append(key)
        while len(self._order) > self._max:
            evict = self._order.pop(0)
            self._data.pop(evict, None)


# ---------- public entry point ---------------------------------------------


def backward(
    dag: ProvenanceDAG,
    feedback: BackwardFeedback,
    *,
    deriver: BackwardDeriver | None = None,
) -> list[BackwardGradient]:
    """Run the backward-pass algorithm.

    Wraps :meth:`ProvenanceDAG.backward` with a process-wide gradient
    cache so the LLM is not re-queried for an identical
    ``(ancestor, descendant, feedback_text)`` tuple. The cache lives
    on the function object; for cross-process caching, the
    ``backward_gradients`` table in the store is the source of truth.
    """
    cache: _GradientCache = getattr(backward, "_cache", None) or _GradientCache()
    setattr(backward, "_cache", cache)
    return dag.backward(feedback, deriver=deriver)


__all__ = [
    "BackwardFeedback",
    "BackwardGradient",
    "BackwardDeriver",
    "LLMClient",
    "LLMBackwardDeriver",
    "StaticBackwardDeriver",
    "backward",
]
