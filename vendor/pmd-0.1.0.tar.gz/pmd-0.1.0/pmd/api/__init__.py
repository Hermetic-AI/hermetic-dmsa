"""Public API layer — the Layer 2 user-facing surface.

The functions here are thin wrappers over the core DAG plus the
backward/lineage/version helpers. Real logic lives in
:mod:`pmd.core.dag` and :mod:`pmd.orchestrator` (we don't have a
separate orchestrator module yet, so the in-process code in
:mod:`pmd.core.dag.ProvenanceDAG` plays that role).
"""

from __future__ import annotations

from pmd.api.add import MemoryRequest, add_memory
from pmd.api.backward import (
    BackwardDeriver,
    BackwardFeedback,
    BackwardGradient,
    LLMBackwardDeriver,
    StaticBackwardDeriver,
    backward,
)
from pmd.api.lineage import (
    get_ancestors,
    get_descendants,
    get_lineage_path,
    get_subgraph,
)

__all__ = [
    "add_memory",
    "MemoryRequest",
    "backward",
    "BackwardFeedback",
    "BackwardGradient",
    "BackwardDeriver",
    "LLMBackwardDeriver",
    "StaticBackwardDeriver",
    "get_ancestors",
    "get_descendants",
    "get_lineage_path",
    "get_subgraph",
]
