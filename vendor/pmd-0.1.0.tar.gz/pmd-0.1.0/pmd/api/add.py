"""``add_memory`` — the high-level user-facing entry point.

This module is what an application calls. It:

1. Validates the :class:`MemoryRequest` (content type matches content).
2. Generates a ULID if the request didn't bring one.
3. Builds the parent edges (one per ``parent_id``).
4. Calls the DAG's :meth:`add_node` with the constructed
   :class:`MemoryNode`.
5. Returns the stored node.

Idempotency: if the same ``idempotency_key`` was already used, the
function returns the previously-stored node without writing again.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from pmd.core.dag import ProvenanceDAG
from pmd.core.enums import ContentType, EdgeType
from pmd.core.node import CreatorEdge, MemoryNode
from pmd.core.prompt import PromptContext
from pmd.utils.ids import generate_id


class MemoryRequest(BaseModel):
    """Validated input for :func:`add_memory`.

    Attributes:
        content: The memory's textual content.
        content_type: See :class:`~pmd.core.enums.ContentType`.
        parents: Parent node IDs. Each gets a ``DERIVED_FROM`` edge.
        prompt_context: The LLM call that produced this memory.
        tags: Free-form tags for retrieval.
        importance: Score in [0, 1].
        requires_grad: Whether backward pass may touch this node.
        grad_learning_rate: Strength of the textual derivative.
        ttl: Seconds until expiration; ``None`` = eternal.
        idempotency_key: Optional caller-supplied key. If the same key
            was used in a prior call, the prior node is returned
            without a new write.
    """

    model_config = ConfigDict(extra="forbid")

    content: str
    content_type: ContentType = ContentType.TEXT
    parents: list[str] = Field(default_factory=list)
    prompt_context: PromptContext | None = None
    tags: list[str] = Field(default_factory=list)
    importance: float = 0.5
    requires_grad: bool = False
    grad_learning_rate: float = 0.0
    ttl: float | None = None
    idempotency_key: str | None = None


def _build_creation_context(
    request: MemoryRequest,
) -> dict[str, Any]:
    """Build the node's ``creation_context`` from the request.

    The PromptContext does not have its own ``creation_context`` field
    (the spec only has it on ``MemoryNode``). We start from an empty
    dict and optionally add the idempotency key.
    """
    base: dict[str, Any] = {}
    if request.idempotency_key is not None:
        base["idempotency_key"] = request.idempotency_key
    return base


def add_memory(dag: ProvenanceDAG, request: MemoryRequest) -> MemoryNode:
    """Add a memory to the DAG.

    Args:
        dag: A :class:`ProvenanceDAG` with a store attached.
        request: Validated :class:`MemoryRequest`.

    Returns:
        The stored :class:`MemoryNode`. If the request supplied an
        ``idempotency_key`` that was used before, the *prior* node is
        returned (no new write).

    Raises:
        MissingParentError: If a parent ID doesn't exist.
        ValidationError: On malformed request (Pydantic).
    """
    # Idempotency check: scan the store for a node whose
    # ``creation_context["idempotency_key"]`` matches. We use
    # ``creation_context`` so the same key can be reused across
    # different content_types without colliding.
    if request.idempotency_key is not None:
        existing = _find_by_idempotency_key(dag, request.idempotency_key)
        if existing is not None:
            return existing

    # First pass: build the node without parent edges so we have a
    # stable ID to reference from the edges.
    prompt = request.prompt_context or PromptContext()
    creation_context = _build_creation_context(request)
    node = MemoryNode(
        id=generate_id(),
        content=request.content,
        content_type=request.content_type,
        tags=request.tags,
        importance=request.importance,
        requires_grad=request.requires_grad,
        grad_learning_rate=request.grad_learning_rate,
        ttl=request.ttl,
        creator_prompt_id=prompt.prompt_id,
        creator_agent_id=prompt.agent_id,
        creation_context=creation_context,
    )

    # Second pass: build the parent edges, now that we know ``node.id``.
    # We use ``DERIVED_FROM`` as the default; the caller can use
    # ``add_edge`` directly to attach a different edge type.
    edges: list[CreatorEdge] = [
        CreatorEdge(
            from_node_id=parent_id,
            to_node_id=node.id,
            edge_type=EdgeType.DERIVED_FROM,
        )
        for parent_id in request.parents
    ]
    node = node.model_copy(update={"parents": edges})

    stored = dag.add_node(node, compute_embedding=True)
    # Persist the prompt context if we have one. We do this *after*
    # the node is stored so the FK relation is consistent.
    if request.prompt_context is not None and dag.store is not None:
        dag.store.put_prompt_context(request.prompt_context)
    return stored


def _find_by_idempotency_key(
    dag: ProvenanceDAG, key: str
) -> MemoryNode | None:
    """Linear scan for a node whose ``creation_context.idempotency_key`` matches.

    O(N) — fine at the call frequency of an agent (≤ 1k writes/s). If
    this becomes a hot path, add an indexed column in the store.
    """
    if dag.store is None:
        return None
    for nid in dag.store.list_nodes():
        node = dag.store.get_node(nid)
        if node is None:
            continue
        if node.creation_context.get("idempotency_key") == key:
            return node
    return None


__all__ = ["add_memory", "MemoryRequest"]
