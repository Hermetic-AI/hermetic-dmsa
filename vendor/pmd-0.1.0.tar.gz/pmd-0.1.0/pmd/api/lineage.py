"""Lineage query helpers — the public read-side API for the DAG.

These are thin functions over :class:`ProvenanceDAG`'s
``get_ancestors`` / ``get_descendants`` / ``get_lineage_path`` with
optional post-filtering by edge type, depth, and status.
"""

from __future__ import annotations

from typing import Iterable

from pmd.core.dag import ProvenanceDAG
from pmd.core.enums import EdgeType, NodeStatus
from pmd.core.node import MemoryNode
from pmd.errors import LineageNotFoundError


def get_ancestors(
    dag: ProvenanceDAG,
    node_id: str,
    *,
    depth: int | None = None,
    edge_types: Iterable[EdgeType] | None = None,
    statuses: Iterable[NodeStatus] | None = None,
) -> list[MemoryNode]:
    """Return the ancestors of ``node_id``, optionally filtered.

    Args:
        dag: The DAG to query.
        node_id: The starting node.
        depth: Maximum hop count. ``None`` = use the DAG default
            (``DEFAULT_MAX_DEPTH`` = 50).
        edge_types: If provided, only traverse these edge types.
        statuses: If provided, drop ancestors whose status is not in
            this set.
    """
    nodes = dag.get_ancestors(node_id, depth=depth, edge_types=edge_types)
    if statuses is not None:
        allowed = set(statuses)
        nodes = [n for n in nodes if n.status in allowed]
    return nodes


def get_descendants(
    dag: ProvenanceDAG,
    node_id: str,
    *,
    depth: int | None = None,
    edge_types: Iterable[EdgeType] | None = None,
    statuses: Iterable[NodeStatus] | None = None,
) -> list[MemoryNode]:
    nodes = dag.get_descendants(node_id, depth=depth, edge_types=edge_types)
    if statuses is not None:
        allowed = set(statuses)
        nodes = [n for n in nodes if n.status in allowed]
    return nodes


def get_lineage_path(
    dag: ProvenanceDAG, from_id: str, to_id: str
) -> list[MemoryNode] | None:
    """Return the *nodes* on the shortest path from ``from_id`` to
    ``to_id`` ancestor.

    Returns ``None`` if no path exists. The list excludes the start
    node and includes the end node.
    """
    edges = dag.get_lineage_path(from_id, to_id)
    if edges is None:
        return None
    result: list[MemoryNode] = []
    for e in edges:
        n = dag.get_node(e.to_node_id)
        if n is not None and (not result or result[-1].id != n.id):
            result.append(n)
    return result


def get_subgraph(
    dag: ProvenanceDAG, root_id: str, *, depth: int = 2
) -> list[MemoryNode]:
    """Return the root, its ancestors, and its descendants up to ``depth``.

    Useful for rendering a node's local context without pulling the
    whole graph.
    """
    if root_id not in dag:
        raise LineageNotFoundError(
            f"node {root_id!r} not found", details={"node_id": root_id}
        )
    root = dag.get_node(root_id)
    ancestors = dag.get_ancestors(root_id, depth=depth)
    descendants = dag.get_descendants(root_id, depth=depth)
    seen: dict[str, MemoryNode] = {root.id: root}
    for n in ancestors + descendants:
        seen[n.id] = n
    return list(seen.values())


__all__ = [
    "get_ancestors",
    "get_descendants",
    "get_lineage_path",
    "get_subgraph",
]
