"""Provenance-aware Memory DAG (PMD) — public API.

This package implements the architecture specified in
``analysis/01b_pmd_architecture.md``. It provides:

- A versioned, immutable record of memory nodes with prompt-level lineage.
- A typed, bidirectional DAG of ``CreatorEdge`` connections.
- A pluggable storage layer (in-memory, SQLite, optional Neo4j).
- A backward propagation engine that mirrors textgrad's chain rule over
  the persistent DAG.
- A lineage-aware retrieval algorithm that augments vector similarity with
  graph-distance proximity.
- Snapshot / rollback / diff primitives that make the graph reversible.

The design goal is to make the *origin* of every memory queryable, and to
make every mutation reversible. See the architecture document for the
authoritative spec.
"""

from __future__ import annotations

from pmd.core.dag import ProvenanceDAG
from pmd.core.enums import (
    ContentType,
    EdgeType,
    FeedbackSource,
    NodeStatus,
    PropagationStrategy,
)
from pmd.core.node import CreatorEdge, MemoryNode
from pmd.core.prompt import PromptContext
from pmd.core.version import DAGDiff, VersionChain, VersionSnapshot
from pmd.errors import (
    BackwardPropagationError,
    DAGInconsistencyError,
    EmbeddingError,
    LineageNotFoundError,
    PMDError,
    RequiresGradViolationError,
    StorageError,
    VersionConflictError,
)

__version__ = "0.1.0"

__all__ = [
    # version
    "__version__",
    # core data model
    "ProvenanceDAG",
    "MemoryNode",
    "CreatorEdge",
    "PromptContext",
    "VersionSnapshot",
    "VersionChain",
    "DAGDiff",
    # enums
    "EdgeType",
    "ContentType",
    "NodeStatus",
    "PropagationStrategy",
    "FeedbackSource",
    # errors
    "PMDError",
    "StorageError",
    "DAGInconsistencyError",
    "BackwardPropagationError",
    "VersionConflictError",
    "LineageNotFoundError",
    "RequiresGradViolationError",
    "EmbeddingError",
]
