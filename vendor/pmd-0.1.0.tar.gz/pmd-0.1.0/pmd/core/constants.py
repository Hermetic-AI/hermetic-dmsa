"""Constants shared across the core layer.

Defined in their own module to avoid the circular import between
:mod:`pmd.core.dag` and :mod:`pmd.core.operations` (both want
``DEFAULT_MAX_DEPTH``).
"""

from __future__ import annotations

# Default cap for unbounded lineage walks. Matches the architecture
# document's `max_depth=50` and keeps recursive walks out of the
# "process OOM" failure mode in 01d §F15.
DEFAULT_MAX_DEPTH = 50

__all__ = ["DEFAULT_MAX_DEPTH"]
