"""Higher-level operations on :class:`ProvenanceDAG`.

Extracted from ``pmd.core.dag`` to keep that file under the 400-line
budget. The functions here are *methods* on the DAG class but are
implemented as free functions so they can be tested in isolation and
unit-imported without dragging the full DAG state machine.

Three operations live here:

1. **Backward propagation** — the §7 algorithm.
2. **Lineage-aware search** — the §9 algorithm.
3. **Export / import** — JSON and Graphviz DOT.

The DAG calls into these via thin delegating methods, e.g.
``dag.backward(feedback)`` -> ``backward(dag, feedback)``.
"""

from __future__ import annotations

import hashlib
import json
import math
from collections import deque
from typing import Any, Iterable

import networkx as nx

from pmd.core.constants import DEFAULT_MAX_DEPTH
from pmd.core.enums import EdgeType, PropagationStrategy
from pmd.core.node import CreatorEdge, MemoryNode
from pmd.errors import DAGInconsistencyError
from pmd.utils.ids import generate_id


def _min_graph_distance(source: str, targets: set[str], dag: Any) -> int:
    """Shortest undirected path from ``source`` to the closest of ``targets``.

    Bounded by ``DEFAULT_MAX_DEPTH`` to prevent pathological walks.
    """
    if source in targets:
        return 0
    seen: set[str] = {source}
    frontier: deque[tuple[str, int]] = deque([(source, 0)])
    while frontier:
        current, d = frontier.popleft()
        if d >= DEFAULT_MAX_DEPTH:
            continue
        for nxt in list(dag._forward_index.get(current, ())) + list(
            dag._reverse_index.get(current, ())
        ):
            if nxt in seen:
                continue
            seen.add(nxt)
            if nxt in targets:
                return d + 1
            frontier.append((nxt, d + 1))
    return DEFAULT_MAX_DEPTH + 1


def _cosine(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    if na == 0.0 or nb == 0.0:
        return 0.0
    return max(0.0, min(1.0, dot / (na * nb)))


def _edge_types_for_strategy(strategy: PropagationStrategy) -> set[EdgeType] | None:
    if strategy == PropagationStrategy.PARTIAL:
        return {EdgeType.DERIVED_FROM}
    return None


# ---------- backward -------------------------------------------------------


def backward(dag: Any, feedback: Any, deriver: Any) -> list[Any]:
    """Run the §7 algorithm.

    Returns one :class:`BackwardGradient` per trainable ancestor.
    The caller is responsible for the cache and the lock.
    """
    from pmd.api.backward import BackwardGradient, LLMBackwardDeriver

    if deriver is None:
        deriver = LLMBackwardDeriver(model="deterministic-stub")

    leaf = dag._nodes.get(feedback.target_node_id)
    if leaf is None:
        from pmd.errors import LineageNotFoundError

        raise LineageNotFoundError(
            f"target node {feedback.target_node_id!r} not found",
            details={"node_id": feedback.target_node_id},
        )

    edge_types = _edge_types_for_strategy(feedback.propagation_strategy)
    ancestors = dag.get_ancestors(
        feedback.target_node_id, depth=feedback.max_depth, edge_types=edge_types
    )
    # Reverse so we walk root -> leaf, with the leaf first. The audit's
    # chain rule carries the signal from the leaf up to the root.
    ancestors_reversed = list(reversed(ancestors))
    ancestors_reversed.append(leaf)
    gradients: list[BackwardGradient] = []
    downstream = leaf
    for ancestor in ancestors_reversed:
        if not ancestor.requires_grad:
            continue
        if ancestor.grad_learning_rate <= 0.0:
            if (
                feedback.propagation_strategy
                == PropagationStrategy.STOP_AT_GRAD_BOUNDARY
            ):
                break
            continue
        eta = ancestor.grad_learning_rate * feedback.severity
        prompt = (
            f"Compute the textual partial derivative of "
            f"{ancestor.id!r} given downstream feedback on "
            f"{downstream.id!r}: {feedback.feedback_text}"
        )
        grad_text, llm_used, tokens = deriver.derive(prompt)
        scaled = f"[eta={eta:.2f}] {grad_text}"
        edge = dag._edges.get(
            (ancestor.id, downstream.id, EdgeType.DERIVED_FROM.value)
        )
        grad = BackwardGradient(
            edge=edge,
            gradient_text=scaled,
            llm_used=llm_used,
            token_cost=tokens,
            ancestor_node_id=ancestor.id,
            descendant_node_id=downstream.id,
            feedback_source=feedback.source.value
            if hasattr(feedback.source, "value")
            else str(feedback.source),
            severity=feedback.severity,
        )
        gradients.append(grad)
        if dag._store is not None:
            dag._store.append_backward_gradient(grad)
        new_ancestor = ancestor.with_appended_feedback(scaled, eta)
        dag._nodes[ancestor.id] = new_ancestor
        if dag._store is not None:
            dag._store.put_node(new_ancestor)
        downstream = new_ancestor
    return gradients


# ---------- lineage-aware search ------------------------------------------


def lineage_aware_search(
    dag: Any,
    query: str,
    q_vec: list[float],
    *,
    k: int = 10,
    depth: int = 2,
    alpha: float = 0.6,
    beta: float = 0.3,
    gamma: float = 0.1,
) -> list[MemoryNode]:
    """Score = alpha * cosine + beta * proximity + gamma * importance.

    Implements the algorithm in ``01b_pmd_architecture.md`` §9. The
    caller supplies the query embedding (so a single embed call is
    reused across many searches).
    """
    candidates: dict[str, tuple[float, MemoryNode]] = {}
    for node in dag._nodes.values():
        if node.embedding is None:
            continue
        score = _cosine(node.embedding, q_vec)
        candidates[node.id] = (score, node)
    top = sorted(candidates.values(), key=lambda t: t[0], reverse=True)[: 2 * k]
    seed_ids = {n.id for _, n in top}

    neighbourhood: set[str] = set()
    for seed in seed_ids:
        for anc in dag.get_ancestors(
            seed,
            depth=depth,
            edge_types={EdgeType.DERIVED_FROM, EdgeType.CREATED_FROM},
        ):
            neighbourhood.add(anc.id)
    candidate_ids = seed_ids | neighbourhood
    for cid in candidate_ids:
        if cid not in candidates:
            node = dag._nodes.get(cid)
            if node is not None:
                candidates[cid] = (0.0, node)

    scored: list[tuple[float, MemoryNode]] = []
    for cid, (cos, node) in candidates.items():
        if cid not in candidate_ids:
            continue
        prox_dist = _min_graph_distance(cid, seed_ids, dag)
        prox = 1.0 / (1.0 + prox_dist) if prox_dist < DEFAULT_MAX_DEPTH + 1 else 0.0
        score = alpha * cos + beta * prox + gamma * node.importance
        scored.append((score, node))
    scored.sort(key=lambda t: t[0], reverse=True)
    return [n for _, n in scored[:k]]


# ---------- export ---------------------------------------------------------


def export_dot(dag: Any, root_id: str | None = None) -> str:
    """Render the DAG (or a subtree) as Graphviz DOT."""
    g = nx.DiGraph()
    if root_id:
        nodes: dict[str, MemoryNode] = {root_id: dag._nodes[root_id]}
        for n in dag.get_descendants(root_id):
            nodes[n.id] = n
    else:
        nodes = dict(dag._nodes)
    for nid, n in nodes.items():
        g.add_node(
            nid,
            label=f"{nid[:8]}\\n{n.content_type.value}",
            status=n.status.value,
        )
    for edge in dag._edges.values():
        if edge.from_node_id in nodes and edge.to_node_id in nodes:
            g.add_edge(
                edge.from_node_id,
                edge.to_node_id,
                label=edge.edge_type.value,
            )
    try:
        from networkx.drawing.nx_pydot import to_pydot

        pdot = to_pydot(g)
        return pdot.to_string()
    except Exception:
        return _render_dot_manual(nodes, dag)


def _render_dot_manual(nodes: dict[str, MemoryNode], dag: Any) -> str:
    lines = ["digraph ProvenanceDAG {", "  rankdir=LR;", "  node [shape=box];"]
    for nid, n in nodes.items():
        label = f"{nid[:8]}\\n{n.content_type.value}"
        lines.append(f'  "{nid}" [label="{label}"];')
    for edge in dag._edges.values():
        if edge.from_node_id in nodes and edge.to_node_id in nodes:
            lines.append(
                f'  "{edge.from_node_id}" -> "{edge.to_node_id}" '
                f'[label="{edge.edge_type.value}"];'
            )
    lines.append("}")
    return "\n".join(lines)


def export_json(dag: Any) -> dict[str, Any]:
    """Serialise the in-memory state. Round-trip via ``import_json``."""
    return {
        "version": 1,
        "nodes": [n.model_dump(mode="json") for n in dag._nodes.values()],
        "edges": [e.model_dump(mode="json") for e in dag._edges.values()],
        "snapshots": [
            s.model_dump(mode="json") for s in dag._version_chain.snapshots.values()
        ],
        "content_hash": hashlib.sha256(
            json.dumps(
                [n.model_dump(mode="json") for n in dag._nodes.values()],
                sort_keys=True,
            ).encode()
        ).hexdigest(),
    }


def import_json(dag: Any, payload: dict[str, Any]) -> None:
    """Rehydrate from an :func:`export_json` payload."""
    from pmd.core.node import MemoryNode
    from pmd.core.version import VersionSnapshot
    from pmd.errors import DAGInconsistencyError
    from collections import defaultdict

    if dag._store is None:
        raise DAGInconsistencyError(
            "no store attached",
            details={"hint": "call attach_store() before import_json"},
        )
    dag._nodes = {}
    dag._edges = {}
    dag._forward_index = defaultdict(list)
    dag._reverse_index = defaultdict(list)
    dag._root_ids = set()
    dag._leaf_ids = set()

    for raw in payload.get("nodes", []):
        node = MemoryNode.model_validate(raw)
        dag._nodes[node.id] = node
        dag._store.put_node(node)
    for raw in payload.get("edges", []):
        edge = CreatorEdge.model_validate(raw)
        dag._edges[edge.edge_key()] = edge
        dag._forward_index[edge.from_node_id].append(edge.to_node_id)
        dag._reverse_index[edge.to_node_id].append(edge.from_node_id)
        dag._store.put_edge(edge)

    all_ids = set(dag._nodes)
    parents_of = {p for ps in dag._reverse_index.values() for p in ps}
    dag._root_ids = all_ids - parents_of
    children_of = {c for cs in dag._forward_index.values() for c in cs}
    dag._leaf_ids = all_ids - children_of

    for raw in payload.get("snapshots", []):
        snap = VersionSnapshot.model_validate(raw)
        dag._version_chain.snapshots[snap.version_id] = snap


__all__ = [
    "backward",
    "lineage_aware_search",
    "export_dot",
    "export_json",
    "import_json",
]
