"""Lineage traversal helpers — the read-side core.

The DAG class has these as methods, but the *implementations* are
factored out into free functions so they can be unit-tested in
isolation and so the DAG file stays under the 400-line budget.

Every function takes the DAG as the first argument (``self`` would
be too implicit). They do not acquire the DAG lock — the caller is
expected to do so.
"""

from __future__ import annotations

from collections import deque
from typing import Any, Iterable

from pmd.core.constants import DEFAULT_MAX_DEPTH
from pmd.core.enums import EdgeType
from pmd.core.node import CreatorEdge, MemoryNode
from pmd.errors import LineageNotFoundError


def get_ancestors(
    dag: Any,
    node_id: str,
    *,
    depth: int | None = DEFAULT_MAX_DEPTH,
    edge_types: Iterable[EdgeType] | None = None,
) -> list[MemoryNode]:
    """Iterative BFS over the reverse index."""
    if node_id not in dag._nodes:
        raise LineageNotFoundError(
            f"node {node_id!r} not found", details={"node_id": node_id}
        )
    types = set(edge_types) if edge_types else None
    seen: set[str] = {node_id}
    results: list[MemoryNode] = []
    frontier: deque[tuple[str, int]] = deque([(node_id, 0)])
    while frontier:
        current, d = frontier.popleft()
        if depth is not None and d >= depth:
            continue
        for parent_id in dag._reverse_index.get(current, ()):
            if parent_id in seen:
                continue
            if types is not None:
                if not any(
                    dag._edges.get((parent_id, current, t.value)) is not None
                    for t in types
                ):
                    continue
            seen.add(parent_id)
            parent = dag._nodes.get(parent_id)
            if parent is not None:
                results.append(parent)
                frontier.append((parent_id, d + 1))
    return results


def get_descendants(
    dag: Any,
    node_id: str,
    *,
    depth: int | None = DEFAULT_MAX_DEPTH,
    edge_types: Iterable[EdgeType] | None = None,
) -> list[MemoryNode]:
    if node_id not in dag._nodes:
        raise LineageNotFoundError(
            f"node {node_id!r} not found", details={"node_id": node_id}
        )
    types = set(edge_types) if edge_types else None
    seen: set[str] = {node_id}
    results: list[MemoryNode] = []
    frontier: deque[tuple[str, int]] = deque([(node_id, 0)])
    while frontier:
        current, d = frontier.popleft()
        if depth is not None and d >= depth:
            continue
        for child_id in dag._forward_index.get(current, ()):
            if child_id in seen:
                continue
            if types is not None:
                if not any(
                    dag._edges.get((current, child_id, t.value)) is not None
                    for t in types
                ):
                    continue
            seen.add(child_id)
            child = dag._nodes.get(child_id)
            if child is not None:
                results.append(child)
                frontier.append((child_id, d + 1))
    return results


def get_lineage_path(
    dag: Any, from_id: str, to_id: str
) -> list[CreatorEdge] | None:
    """Shortest path (BFS) from ``from_id``'s ancestors to ``to_id``'s
    ancestors. Returns ``None`` if no path exists."""
    if from_id not in dag._nodes or to_id not in dag._nodes:
        raise LineageNotFoundError(
            f"node not found",
            details={"from_id": from_id, "to_id": to_id},
        )
    if from_id == to_id:
        return []

    def walk_up(start: str) -> dict[str, list[CreatorEdge]]:
        chain: dict[str, list[CreatorEdge]] = {start: []}
        frontier: deque[str] = deque([start])
        while frontier:
            current = frontier.popleft()
            for parent_id in dag._reverse_index.get(current, ()):
                if parent_id in chain:
                    continue
                edge = dag._edges.get(
                    (parent_id, current, EdgeType.DERIVED_FROM.value)
                ) or dag._edges.get(
                    (parent_id, current, EdgeType.CREATED_FROM.value)
                )
                if edge is None:
                    continue
                chain[parent_id] = chain[current] + [edge]
                frontier.append(parent_id)
        return chain

    from_chain = walk_up(from_id)
    to_chain = walk_up(to_id)
    best: tuple[int, list[CreatorEdge]] | None = None
    for ancestor, fpath in from_chain.items():
        if ancestor in to_chain:
            tpath = to_chain[ancestor]
            tpath_reversed = list(reversed(tpath))
            total = fpath + tpath_reversed
            if best is None or len(total) < best[0]:
                best = (len(total), total)
    return best[1] if best is not None else None


__all__ = ["get_ancestors", "get_descendants", "get_lineage_path"]
