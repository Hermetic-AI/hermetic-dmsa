"""Versioning primitives — snapshots, diffs, and the version chain.

A :class:`VersionSnapshot` is an immutable record of the DAG at a point
in time. The DAG's source of truth lives in a :class:`ProvenanceStore`; a
snapshot stores a *manifest* (id, counts, content hash, description) plus
a ``dag_state_ref`` that points into the store. Rollback restores the
state referenced by the manifest; diff compares two manifests.
"""

from __future__ import annotations

import hashlib
import json
import time
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from pmd.core.node import CreatorEdge, MemoryNode


def _now() -> float:
    return time.time()


class VersionSnapshot(BaseModel):
    """An immutable snapshot of the entire DAG.

    A snapshot does **not** copy every node and edge into a new table —
    it stores a manifest and a ``dag_state_ref`` (e.g. a SHA-256
    pointing to an immutable copy in the store). Rollback restores
    from that ref.

    Attributes:
        version_id: ULID of the snapshot itself.
        parent_version_id: The prior snapshot's ID, forming a commit
            DAG (snapshots can be branched).
        created_at: Unix seconds when the snapshot was taken.
        dag_state_ref: A store-specific pointer (path, hash, URI) to
            the immutable copy of the DAG.
        description: Free-form human description.
        tag: Optional tag string (e.g. ``"v0.3-release"``).
        node_count: Number of nodes that existed at snapshot time.
        edge_count: Number of edges that existed at snapshot time.
        content_hash: SHA-256 of the canonical JSON of the snapshot's
            node/edge sets. Used for cheap equality checks and tamper
            detection.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    version_id: str
    parent_version_id: str | None = None
    created_at: float = Field(default_factory=_now)
    dag_state_ref: str = ""
    description: str = ""
    tag: str | None = None
    node_count: int = 0
    edge_count: int = 0
    content_hash: str = ""

    def __hash__(self) -> int:  # type: ignore[override]
        return hash(self.version_id)

    @staticmethod
    def compute_content_hash(
        nodes: list[MemoryNode], edges: list[CreatorEdge]
    ) -> str:
        """SHA-256 of a canonical serialisation of (nodes, edges).

        The hash is *order-independent* (we sort by id / edge key
        before serialising) so a diff is just a hash compare. This is
        the same scheme git uses for tree objects.
        """
        node_payload = sorted(
            (n.model_dump(mode="json", exclude={"parents", "children"}) for n in nodes),
            key=lambda d: d["id"],
        )
        edge_payload = sorted(
            (e.model_dump(mode="json") for e in edges),
            key=lambda d: (d["from_node_id"], d["to_node_id"], d["edge_type"]),
        )
        blob = json.dumps(
            {"nodes": node_payload, "edges": edge_payload},
            sort_keys=True,
            default=str,
        ).encode("utf-8")
        return hashlib.sha256(blob).hexdigest()


class DAGDiff(BaseModel):
    """The structured result of ``diff(v1, v2)``.

    All four collection fields are present even when empty, so a caller
    can always iterate without a ``hasattr`` check. ``summary`` is a
    one-line human-readable rendering.

    Attributes:
        added_nodes: Nodes present in v2 but not v1.
        removed_nodes: IDs of nodes present in v1 but not v2.
        modified_nodes: Pairs of ``(old, new)`` for nodes whose
            content changed.
        added_edges: Edges present in v2 but not v1.
        removed_edges: Edges present in v1 but not v2.
        summary: Human-readable rendering.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    added_nodes: list[MemoryNode] = Field(default_factory=list)
    removed_nodes: list[str] = Field(default_factory=list)
    modified_nodes: list[tuple[MemoryNode, MemoryNode]] = Field(
        default_factory=list
    )
    added_edges: list[CreatorEdge] = Field(default_factory=list)
    removed_edges: list[CreatorEdge] = Field(default_factory=list)
    summary: str = ""

    def is_empty(self) -> bool:
        """``True`` iff every collection is empty."""
        return not (
            self.added_nodes
            or self.removed_nodes
            or self.modified_nodes
            or self.added_edges
            or self.removed_edges
        )

    @staticmethod
    def build(
        old_nodes: dict[str, MemoryNode],
        new_nodes: dict[str, MemoryNode],
        old_edges: dict[tuple[str, str, str], CreatorEdge],
        new_edges: dict[tuple[str, str, str], CreatorEdge],
    ) -> DAGDiff:
        """Compute the diff between two node/edge snapshots.

        We do a sorted-merge pass per collection; cost is O(N + E).
        """
        added_nodes: list[MemoryNode] = []
        removed_nodes: list[str] = []
        modified_nodes: list[tuple[MemoryNode, MemoryNode]] = []

        old_ids = set(old_nodes)
        new_ids = set(new_nodes)

        for nid in sorted(old_ids - new_ids):
            removed_nodes.append(nid)
        for nid in sorted(new_ids - old_ids):
            added_nodes.append(new_nodes[nid])
        for nid in sorted(old_ids & new_ids):
            old = old_nodes[nid]
            new = new_nodes[nid]
            # Compare on the fields that *matter* for content drift.
            # Timestamps and access counters are not "modifications".
            if (
                old.content != new.content
                or old.structured_payload != new.structured_payload
                or old.tags != new.tags
                or old.importance != new.importance
                or old.status != new.status
                or old.version != new.version
            ):
                modified_nodes.append((old, new))

        added_edges: list[CreatorEdge] = []
        removed_edges: list[CreatorEdge] = []
        old_keys = set(old_edges)
        new_keys = set(new_edges)
        for k in sorted(new_keys - old_keys):
            added_edges.append(new_edges[k])
        for k in sorted(old_keys - new_keys):
            removed_edges.append(old_edges[k])

        summary = (
            f"+{len(added_nodes)} nodes, -{len(removed_nodes)} nodes, "
            f"~{len(modified_nodes)} modified, "
            f"+{len(added_edges)} edges, -{len(removed_edges)} edges"
        )
        return DAGDiff(
            added_nodes=added_nodes,
            removed_nodes=removed_nodes,
            modified_nodes=modified_nodes,
            added_edges=added_edges,
            removed_edges=removed_edges,
            summary=summary,
        )


class VersionChain(BaseModel):
    """A pointer into the snapshot DAG.

    A ``VersionChain`` is the in-memory representation of the
    ``version_snapshots`` table — a mapping from version_id to
    :class:`VersionSnapshot` plus a ``head_id`` indicating the current
    tip. ``walk_history`` returns the linear chain from any snapshot
    back to the root.
    """

    model_config = ConfigDict(extra="forbid")

    snapshots: dict[str, VersionSnapshot] = Field(default_factory=dict)
    head_id: str | None = None

    def add(self, snap: VersionSnapshot) -> None:
        """Append a snapshot. Updates ``head_id`` to point at it."""
        self.snapshots[snap.version_id] = snap
        self.head_id = snap.version_id

    def walk_history(self, version_id: str) -> list[VersionSnapshot]:
        """Return the chain from ``version_id`` back to the root.

        Includes the input as the first element. Returns an empty list
        if the input is not a known snapshot.
        """
        chain: list[VersionSnapshot] = []
        seen: set[str] = set()
        current_id: str | None = version_id
        while current_id is not None and current_id not in seen:
            snap = self.snapshots.get(current_id)
            if snap is None:
                break
            chain.append(snap)
            seen.add(current_id)
            current_id = snap.parent_version_id
        return chain


__all__ = ["VersionSnapshot", "DAGDiff", "VersionChain"]
