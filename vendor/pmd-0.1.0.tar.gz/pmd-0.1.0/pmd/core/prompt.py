"""Prompt-level lineage record.

A :class:`PromptContext` captures a single LLM call (or human input event).
The unit that ``MemoryNode.creator_prompt_id`` references — answering
"which prompt produced this memory?" in O(1) is the central G1 goal from
``01b_pmd_architecture.md``.

The model is frozen so a prompt record is immutable once written;
"edits" create a new context with ``parent_prompt_id`` chained back to
the prior one (a true prompt-DAG, not a flat log).
"""

from __future__ import annotations

import time
import uuid
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


def _new_prompt_id() -> str:
    """Generate a fresh prompt ID.

    We default to a random UUID4 here. The canonical PMD convention is a
    ULID, but :mod:`pmd.utils.ids` lives one layer down and we want the
    core model to depend only on the standard library. Callers that
    want ULIDs can pass an explicit ``prompt_id`` after generating it
    via :func:`pmd.utils.ids.generate_id`.
    """
    return str(uuid.uuid4())


class PromptContext(BaseModel):
    """Immutable record of a single LLM call or human input event.

    Fields mirror ``01b_pmd_architecture.md`` §4.5 exactly.

    Attributes:
        prompt_id: Stable identifier (ULID or UUID).
        agent_id: ULID of the agent that issued the call.
        parent_prompt_id: If this prompt is itself derived from a prior
            prompt (textgrad-style chaining), the parent's ID. ``None``
            for root prompts.
        system_prompt: The system message that framed the call.
        user_prompt: The user / developer message.
        llm_response: The model's response text. ``""`` if the call
            failed before a response was produced.
        model_name: Identifier of the model that produced the response
            (e.g. ``"gpt-4o"``, ``"claude-opus-4-7"``).
        temperature: Sampling temperature; ``0.0`` for greedy.
        request_timestamp: Unix seconds when the request was issued.
        response_timestamp: Unix seconds when the response arrived.
            ``None`` while the call is in flight.
        token_usage: Mapping with ``prompt_tokens`` / ``completion_tokens``
            / ``total`` entries. Empty dict if the LLM SDK did not
            report usage.
        success: ``False`` if the call failed (timeout, 5xx, parse error).
        error: Human-readable error string. ``None`` on success.
        tool_calls: Serialised tool-call records (OpenAI shape).
        retrieved_memory_ids: PMD node IDs that were injected into the
            prompt as retrieval context. Used for G5 lineage-aware
            retrieval debugging.
        few_shot_memory_ids: PMD node IDs used as few-shot exemplars.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    prompt_id: str = Field(default_factory=_new_prompt_id)
    agent_id: str = ""
    parent_prompt_id: str | None = None
    system_prompt: str = ""
    user_prompt: str = ""
    llm_response: str = ""
    model_name: str = ""
    temperature: float = 0.0
    request_timestamp: float = Field(default_factory=time.time)
    response_timestamp: float | None = None
    token_usage: dict[str, int] = Field(default_factory=dict)
    success: bool = True
    error: str | None = None
    tool_calls: list[dict[str, Any]] = Field(default_factory=list)
    retrieved_memory_ids: list[str] = Field(default_factory=list)
    few_shot_memory_ids: list[str] = Field(default_factory=list)

    def __hash__(self) -> int:  # type: ignore[override]
        # Frozen model — hash on the full identity tuple. This is what
        # makes a prompt record usable as a dict key in the cache.
        return hash(self.prompt_id)

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a JSON-safe dictionary (round-trip via ``from_dict``)."""
        return self.model_dump(mode="json")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PromptContext:
        """Inverse of :meth:`to_dict`."""
        return cls.model_validate(data)


__all__ = ["PromptContext"]
