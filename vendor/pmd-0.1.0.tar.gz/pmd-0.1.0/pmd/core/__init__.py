"""Core data model — the Layer 4 heart of PMD.

Re-exports every public symbol from the four submodules so a caller can
do ``from pmd.core import MemoryNode, CreatorEdge, ProvenanceDAG`` and
not have to remember the file layout.
"""

from __future__ import annotations

from pmd.core.dag import ProvenanceDAG
from pmd.core.enums import (
    ContentType,
    EdgeType,
    FeedbackSource,
    NodeStatus,
    PropagationStrategy,
)
from pmd.core.node import (
    DEFAULT_EMBEDDING_DIM,
    CreatorEdge,
    MemoryNode,
)
from pmd.core.prompt import PromptContext
from pmd.core.version import DAGDiff, VersionChain, VersionSnapshot

__all__ = [
    # node
    "MemoryNode",
    "CreatorEdge",
    "DEFAULT_EMBEDDING_DIM",
    # prompt
    "PromptContext",
    # dag
    "ProvenanceDAG",
    # version
    "VersionSnapshot",
    "DAGDiff",
    "VersionChain",
    # enums
    "EdgeType",
    "ContentType",
    "NodeStatus",
    "PropagationStrategy",
    "FeedbackSource",
]
