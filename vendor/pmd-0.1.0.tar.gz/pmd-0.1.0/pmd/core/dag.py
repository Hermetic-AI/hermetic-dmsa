"""The :class:`ProvenanceDAG` — the Layer 4 in-memory graph.

This is the file where the *architecture* (Layer 4) meets the *storage*
(Layer 5). The DAG itself is a thin orchestrator over a
:class:`pmd.store.base.ProvenanceStore`; it adds three things on top:

1. Fast in-memory adjacency indexes (``forward_index``,
   ``reverse_index``) so :meth:`get_ancestors` and
   :meth:`get_descendants` are O(depth), not O(N).
2. Cycle detection on every edge insertion
   (:meth:`_would_create_cycle`).
3. A pluggable embedder so :meth:`add_node` can lazily compute
   embeddings.

The class is *not* frozen — it accumulates state. All mutation goes
through methods that take the DAG lock and write to the store, so
two callers on the same instance are serialised.

The heavier operations — backward propagation, lineage-aware search,
and export/import — live in :mod:`pmd.core.operations` to keep this
file under the 400-line budget.
"""

from __future__ import annotations

import threading
import time
from collections import defaultdict, deque
from typing import Any, Iterable

from pmd.core.constants import DEFAULT_MAX_DEPTH
from pmd.core.enums import (
    ContentType,
    EdgeType,
    NodeStatus,
)
from pmd.core.node import CreatorEdge, MemoryNode
from pmd.core.operations import (
    backward as _op_backward,
)
from pmd.core.operations import (
    export_dot as _op_export_dot,
)
from pmd.core.operations import (
    export_json as _op_export_json,
)
from pmd.core.operations import (
    import_json as _op_import_json,
)
from pmd.core.operations import (
    lineage_aware_search as _op_lineage_search,
)
from pmd.core.prompt import PromptContext
from pmd.core.traversal import (
    get_ancestors as _traversal_ancestors,
)
from pmd.core.traversal import (
    get_descendants as _traversal_descendants,
)
from pmd.core.traversal import (
    get_lineage_path as _traversal_lineage_path,
)
from pmd.core.version import DAGDiff, VersionChain, VersionSnapshot
from pmd.errors import (
    CycleDetectedError,
    DAGInconsistencyError,
    DanglingEdgeError,
    DuplicateEdgeError,
    LineageNotFoundError,
    MissingParentError,
)
from pmd.utils.ids import generate_id

# ``DEFAULT_MAX_DEPTH`` is imported above from :mod:`pmd.core.constants`.
# The constant lives in its own module to avoid a circular import
# with :mod:`pmd.core.operations`.


def _now() -> float:
    return time.time()


class ProvenanceDAG:
    """In-memory graph + LRU cache over a :class:`ProvenanceStore`.

    A single DAG instance is not safe to share across processes; create
    one per process. It *is* safe to share across threads — every
    mutation acquires ``self._lock`` (an :class:`threading.RLock`) and
    reads go through the store's MVCC layer.

    Args:
        store: A :class:`ProvenanceStore` instance (any backend). When
            ``None``, the DAG is initialised empty and a store must be
            attached before any node is added.
        embedder: Optional callable taking a string and returning a
            ``list[float]``. When supplied, ``add_node`` will compute
            an embedding for any node that does not already have one.
            The default is ``None`` (no auto-embedding).
    """

    def __init__(
        self,
        store: Any | None = None,
        embedder: Any | None = None,
    ) -> None:
        self._store = store
        self._embedder = embedder
        self._lock = threading.RLock()

        # In-memory fast indexes. We rebuild these from the store on
        # ``load_from_store()``; for an empty DAG they start empty.
        self._nodes: dict[str, MemoryNode] = {}
        self._edges: dict[tuple[str, str, str], CreatorEdge] = {}
        self._forward_index: dict[str, list[str]] = defaultdict(list)  # id -> children
        self._reverse_index: dict[str, list[str]] = defaultdict(list)  # id -> parents

        # Root/leaf bookkeeping. Maintained on every mutation.
        self._root_ids: set[str] = set()
        self._leaf_ids: set[str] = set()

        # Version chain (the "commit DAG").
        self._version_chain = VersionChain()
        self._snapshot_nodes: dict[str, dict[str, MemoryNode]] = {}
        self._snapshot_edges: dict[
            str, dict[tuple[str, str, str], CreatorEdge]
        ] = {}

        if self._store is not None:
            self.load_from_store()

    # ------------------------------------------------------------------
    # Store attachment
    # ------------------------------------------------------------------

    @property
    def store(self) -> Any:
        return self._store

    def attach_store(self, store: Any) -> None:
        """Attach a store and rehydrate from it."""
        with self._lock:
            self._store = store
            self.load_from_store()

    def load_from_store(self) -> None:
        """Rehydrate in-memory indexes from the attached store."""
        with self._lock:
            if self._store is None:
                return
            self._nodes = {}
            self._edges = {}
            self._forward_index = defaultdict(list)
            self._reverse_index = defaultdict(list)
            self._root_ids = set()
            self._leaf_ids = set()

            for nid in self._store.list_nodes():
                node = self._store.get_node(nid)
                if node is None:
                    continue
                self._nodes[nid] = node
            for edge in self._store.list_edges():
                self._edges[edge.edge_key()] = edge
                self._forward_index[edge.from_node_id].append(edge.to_node_id)
                self._reverse_index[edge.to_node_id].append(edge.from_node_id)

            all_ids = set(self._nodes)
            parents_of: set[str] = {p for ps in self._reverse_index.values() for p in ps}
            self._root_ids = all_ids - parents_of
            children_of: set[str] = {c for cs in self._forward_index.values() for c in cs}
            self._leaf_ids = all_ids - children_of

            for v in self._store.list_snapshots():
                self._version_chain.snapshots[v.version_id] = v
            if self._version_chain.snapshots:
                self._version_chain.head_id = max(
                    self._version_chain.snapshots,
                    key=lambda vid: self._version_chain.snapshots[vid].created_at,
                )

    # ------------------------------------------------------------------
    # Add / remove
    # ------------------------------------------------------------------

    def add_node(
        self,
        node: MemoryNode,
        *,
        compute_embedding: bool = True,
    ) -> MemoryNode:
        """Persist a node. Validates DAG invariants and updates indexes."""
        with self._lock:
            self._require_store()
            for edge in node.parents:
                if edge.from_node_id not in self._nodes:
                    raise MissingParentError(
                        f"parent {edge.from_node_id!r} of node {node.id!r} "
                        "does not exist in the DAG",
                        details={"parent_id": edge.from_node_id, "node_id": node.id},
                    )

            stored_node = node
            if (
                compute_embedding
                and self._embedder is not None
                and stored_node.embedding is None
            ):
                vec = self._embedder.embed(stored_node.content)
                stored_node = stored_node.model_copy(
                    update={"embedding": vec, "embedding_model": self._embedder.name}
                )

            self._store.put_node(stored_node)
            self._nodes[stored_node.id] = stored_node
            if stored_node.id not in self._forward_index:
                self._forward_index[stored_node.id] = []
            if stored_node.id not in self._reverse_index:
                self._reverse_index[stored_node.id] = []

            for edge in stored_node.parents:
                self._add_edge_internal(edge, check_acyclic=True)

            self._refresh_root_leaf(stored_node.id)
            return stored_node

    def add_node_atomic(
        self,
        node: MemoryNode,
        *,
        parents: list[str] | None = None,
        edge_type: EdgeType = EdgeType.DERIVED_FROM,
    ) -> MemoryNode:
        """Atomic variant: validate all parents, then commit in one shot."""
        with self._lock:
            self._require_store()
            edges: list[CreatorEdge] = []
            for parent_id in parents or []:
                if parent_id not in self._nodes:
                    raise MissingParentError(
                        f"parent {parent_id!r} not found",
                        details={"parent_id": parent_id},
                    )
                edges.append(
                    CreatorEdge(
                        from_node_id=parent_id,
                        to_node_id=node.id,
                        edge_type=edge_type,
                    )
                )
            node_with_parents = node.model_copy(update={"parents": edges})
            return self.add_node(node_with_parents, compute_embedding=True)

    def add_edge(self, edge: CreatorEdge) -> None:
        """Add an edge. Rejects if it would create a cycle."""
        with self._lock:
            self._require_store()
            self._add_edge_internal(edge, check_acyclic=True)

    def _add_edge_internal(
        self, edge: CreatorEdge, *, check_acyclic: bool
    ) -> None:
        if edge.from_node_id not in self._nodes:
            raise MissingParentError(
                f"from_node {edge.from_node_id!r} not in DAG",
                details={"edge": edge.model_dump(mode="json")},
            )
        if edge.to_node_id not in self._nodes:
            raise MissingParentError(
                f"to_node {edge.to_node_id!r} not in DAG",
                details={"edge": edge.model_dump(mode="json")},
            )
        if edge.from_node_id == edge.to_node_id:
            raise CycleDetectedError(
                f"self-loop not allowed: {edge.from_node_id}",
                details={"node_id": edge.from_node_id},
            )
        key = edge.edge_key()
        if key in self._edges:
            raise DuplicateEdgeError(
                f"edge {key!r} already exists",
                details={"edge": edge.model_dump(mode="json")},
            )
        if check_acyclic and self._would_create_cycle(edge.from_node_id, edge.to_node_id):
            raise CycleDetectedError(
                f"adding edge {key!r} would create a cycle",
                details={"from": edge.from_node_id, "to": edge.to_node_id},
            )

        self._store.put_edge(edge)
        self._edges[key] = edge
        self._forward_index[edge.from_node_id].append(edge.to_node_id)
        self._reverse_index[edge.to_node_id].append(edge.from_node_id)
        self._refresh_root_leaf(edge.from_node_id)
        self._refresh_root_leaf(edge.to_node_id)

    def _would_create_cycle(self, from_id: str, to_id: str) -> bool:
        """``True`` if the new edge (from -> to) would close a cycle."""
        if from_id == to_id:
            return True
        seen: set[str] = set()
        queue: deque[str] = deque([to_id])
        while queue and len(seen) <= DEFAULT_MAX_DEPTH:
            current = queue.popleft()
            if current == from_id:
                return True
            if current in seen:
                continue
            seen.add(current)
            for child in self._forward_index.get(current, ()):
                if child not in seen:
                    queue.append(child)
        return False

    def _refresh_root_leaf(self, node_id: str) -> None:
        """Recompute whether ``node_id`` is a root (no parents) or leaf
        (no children). Idempotent and cheap."""
        has_parents = bool(self._reverse_index.get(node_id))
        has_children = bool(self._forward_index.get(node_id))
        if not has_parents:
            self._root_ids.add(node_id)
        else:
            self._root_ids.discard(node_id)
        if not has_children:
            self._leaf_ids.add(node_id)
        else:
            self._leaf_ids.discard(node_id)

    def remove_node(self, node_id: str) -> None:
        """Mark a node as DELETED. The row stays in the store for audit."""
        with self._lock:
            self._require_store()
            node = self._nodes.get(node_id)
            if node is None:
                raise LineageNotFoundError(
                    f"node {node_id!r} not found", details={"node_id": node_id}
                )
            tombstoned = node.model_copy(
                update={"status": NodeStatus.DELETED, "updated_at": _now()}
            )
            self._store.put_node(tombstoned)
            self._nodes[node_id] = tombstoned

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def get_node(self, node_id: str) -> MemoryNode:
        if node_id not in self._nodes:
            raise LineageNotFoundError(
                f"node {node_id!r} not found", details={"node_id": node_id}
            )
        return self._nodes[node_id]

    def get_edge(
        self, from_id: str, to_id: str, edge_type: EdgeType
    ) -> CreatorEdge:
        key = (from_id, to_id, edge_type.value)
        edge = self._edges.get(key)
        if edge is None:
            raise DanglingEdgeError(
                f"edge {key!r} not found",
                details={"from": from_id, "to": to_id, "type": edge_type.value},
            )
        return edge

    def get_ancestors(
        self,
        node_id: str,
        *,
        depth: int | None = DEFAULT_MAX_DEPTH,
        edge_types: Iterable[EdgeType] | None = None,
    ) -> list[MemoryNode]:
        """Iterative BFS over the reverse index. See
        :func:`pmd.core.traversal.get_ancestors`."""
        return _traversal_ancestors(
            self, node_id, depth=depth, edge_types=edge_types
        )

    def get_descendants(
        self,
        node_id: str,
        *,
        depth: int | None = DEFAULT_MAX_DEPTH,
        edge_types: Iterable[EdgeType] | None = None,
    ) -> list[MemoryNode]:
        """Iterative BFS over the forward index. See
        :func:`pmd.core.traversal.get_descendants`."""
        return _traversal_descendants(
            self, node_id, depth=depth, edge_types=edge_types
        )

    def get_lineage_path(
        self, from_id: str, to_id: str
    ) -> list[CreatorEdge] | None:
        """Shortest path (BFS) from ``from_id``'s ancestors to ``to_id``'s
        ancestors. See :func:`pmd.core.traversal.get_lineage_path`."""
        return _traversal_lineage_path(self, from_id, to_id)

    def get_creator(self, node_id: str) -> PromptContext | None:
        """O(1) creator lookup. Returns ``None`` if no prompt context
        has been recorded (e.g. for synthetic root nodes)."""
        node = self._nodes.get(node_id)
        if node is None:
            raise LineageNotFoundError(
                f"node {node_id!r} not found", details={"node_id": node_id}
            )
        if not node.creator_prompt_id:
            return None
        if self._store is None:
            return None
        return self._store.get_prompt_context(node.creator_prompt_id)

    # ------------------------------------------------------------------
    # Backward propagation (delegated to operations)
    # ------------------------------------------------------------------

    def backward(
        self,
        feedback: Any,
        deriver: Any | None = None,
    ) -> list[Any]:
        """Run the §7 algorithm. See :func:`pmd.core.operations.backward`."""
        with self._lock:
            self._require_store()
            return _op_backward(self, feedback, deriver)

    # ------------------------------------------------------------------
    # Lineage-aware retrieval (delegated to operations)
    # ------------------------------------------------------------------

    def lineage_aware_search(
        self,
        query: str,
        k: int = 10,
        depth: int = 2,
        alpha: float = 0.6,
        beta: float = 0.3,
        gamma: float = 0.1,
    ) -> list[MemoryNode]:
        """Score = alpha * cosine + beta * proximity + gamma * importance."""
        if self._embedder is None:
            raise DAGInconsistencyError(
                "lineage_aware_search requires an embedder to be attached",
                details={"hint": "pass embedder= when constructing the DAG"},
            )
        with self._lock:
            q_vec = self._embedder.embed(query)
            return _op_lineage_search(
                self,
                query,
                q_vec,
                k=k,
                depth=depth,
                alpha=alpha,
                beta=beta,
                gamma=gamma,
            )

    # ------------------------------------------------------------------
    # Snapshot / rollback / diff
    # ------------------------------------------------------------------

    def snapshot(
        self,
        description: str = "",
        tag: str | None = None,
    ) -> VersionSnapshot:
        """Snapshot the current DAG."""
        with self._lock:
            self._require_store()
            nodes = dict(self._nodes)
            edges = dict(self._edges)
            content_hash = VersionSnapshot.compute_content_hash(
                list(nodes.values()), list(edges.values())
            )
            snap = VersionSnapshot(
                version_id=generate_id(),
                parent_version_id=self._version_chain.head_id,
                created_at=_now(),
                dag_state_ref=content_hash,
                description=description,
                tag=tag,
                node_count=len(nodes),
                edge_count=len(edges),
                content_hash=content_hash,
            )
            self._store.put_snapshot(snap, nodes, edges)
            self._snapshot_nodes[snap.version_id] = nodes
            self._snapshot_edges[snap.version_id] = edges
            self._version_chain.add(snap)
            return snap

    def rollback(self, version_id: str) -> None:
        """Restore the DAG to a prior snapshot's state."""
        with self._lock:
            self._require_store()
            if version_id not in self._snapshot_nodes:
                snap = self._store.get_snapshot(version_id)
                if snap is None:
                    raise LineageNotFoundError(
                        f"snapshot {version_id!r} not found",
                        details={"version_id": version_id},
                    )
                nodes, edges = self._store.load_snapshot_payload(version_id)
                self._snapshot_nodes[version_id] = nodes
                self._snapshot_edges[version_id] = edges
            self._nodes = dict(self._snapshot_nodes[version_id])
            self._edges = dict(self._snapshot_edges[version_id])
            self._forward_index = defaultdict(list)
            self._reverse_index = defaultdict(list)
            for edge in self._edges.values():
                self._forward_index[edge.from_node_id].append(edge.to_node_id)
                self._reverse_index[edge.to_node_id].append(edge.from_node_id)
            all_ids = set(self._nodes)
            parents_of = {p for ps in self._reverse_index.values() for p in ps}
            self._root_ids = all_ids - parents_of
            children_of = {c for cs in self._forward_index.values() for c in cs}
            self._leaf_ids = all_ids - children_of
            self._version_chain.head_id = version_id

    def diff(self, v1: str, v2: str) -> DAGDiff:
        with self._lock:
            if v1 not in self._snapshot_nodes:
                payload = self._store.load_snapshot_payload(v1)
                self._snapshot_nodes[v1] = payload[0]
                self._snapshot_edges[v1] = payload[1]
            if v2 not in self._snapshot_nodes:
                payload = self._store.load_snapshot_payload(v2)
                self._snapshot_nodes[v2] = payload[0]
                self._snapshot_edges[v2] = payload[1]
            return DAGDiff.build(
                self._snapshot_nodes[v1],
                self._snapshot_nodes[v2],
                self._snapshot_edges[v1],
                self._snapshot_edges[v2],
            )

    def list_versions(self) -> list[VersionSnapshot]:
        return list(
            self._version_chain.walk_history(self._version_chain.head_id or "")
        )

    # ------------------------------------------------------------------
    # Export / import (delegated to operations)
    # ------------------------------------------------------------------

    def export_dot(self, root_id: str | None = None) -> str:
        with self._lock:
            return _op_export_dot(self, root_id)

    def export_json(self) -> dict[str, Any]:
        with self._lock:
            return _op_export_json(self)

    def import_json(self, payload: dict[str, Any]) -> None:
        with self._lock:
            self._require_store()
            _op_import_json(self, payload)

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------

    def _require_store(self) -> None:
        if self._store is None:
            raise DAGInconsistencyError(
                "no store attached",
                details={"hint": "call attach_store() before mutating"},
            )

    def __len__(self) -> int:
        return len(self._nodes)

    def __contains__(self, node_id: object) -> bool:
        return isinstance(node_id, str) and node_id in self._nodes


__all__ = ["ProvenanceDAG", "DEFAULT_MAX_DEPTH"]
