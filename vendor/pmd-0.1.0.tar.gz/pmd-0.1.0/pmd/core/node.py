"""Immutable record types: :class:`MemoryNode` and :class:`CreatorEdge`.

Both types are Pydantic models with ``frozen=True`` so that any "edit"
returns a new instance. That is what makes :class:`pmd.core.version.VersionSnapshot`
trivially correct: storing a list of immutable records is the same as
storing the graph at a point in time.

The :class:`MemoryNode` fields mirror ``01b_pmd_architecture.md`` §4.2
verbatim — the architecture document is the spec; do not invent new
fields here.
"""

from __future__ import annotations

import hashlib
import json
import time
from typing import Any

import numpy as np
from pydantic import BaseModel, ConfigDict, Field, field_validator

from pmd.core.enums import ContentType, EdgeType, NodeStatus
from pmd.core.prompt import PromptContext

# Default dimensionality for the embedding column. 1536 covers OpenAI's
# text-embedding-3-small/large; users with a different model can
# override by passing ``embedding=`` with a matching shape.
DEFAULT_EMBEDDING_DIM = 1536


def _new_id() -> str:
    """Fallback ID generator that doesn't require ULID.

    The canonical PMD convention is ULID (see ``pmd.utils.ids``), but the
    core model must not depend on that module (cycle). We mint a random
    UUID4 here as a placeholder; callers that need ULIDs should pre-
    generate the ID with :func:`pmd.utils.ids.generate_id` and pass it
    in.
    """
    import uuid

    return str(uuid.uuid4())


def _now() -> float:
    """``time.time()`` as a float (Unix seconds). Wrapped so tests can
    monkey-patch it from a single location."""
    return time.time()


class MemoryNode(BaseModel):
    """A single memory record in the DAG.

    The field set, types, and defaults come straight from
    ``01b_pmd_architecture.md`` §4.2. Anything that is *not* in the spec
    must not appear here.

    ``frozen=True`` means ``node.foo = bar`` raises ``ValidationError``.
    "Edit" semantics are achieved by calling ``node.model_copy(update=...)``
    which yields a new instance with ``version+1``.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    # --- identity ---------------------------------------------------------
    id: str = Field(default_factory=_new_id)
    version: int = 1

    # --- content ----------------------------------------------------------
    content: str = ""
    content_type: ContentType = ContentType.TEXT
    embedding: list[float] | None = None
    embedding_model: str | None = None
    structured_payload: dict[str, Any] | None = None

    # --- prompt-level lineage (G1) ---------------------------------------
    creator_prompt_id: str = ""
    creator_agent_id: str = ""
    creation_context: dict[str, Any] = Field(default_factory=dict)

    # --- DAG adjacency (G2) ----------------------------------------------
    # ``parents`` and ``children`` are lists of ``CreatorEdge`` records,
    # stored on the node for read convenience; the authoritative copy
    # lives in the store. We keep them here so a serialised node is
    # self-contained (export/import round-trip works).
    parents: list[CreatorEdge] = Field(default_factory=list)  # type: ignore[type-arg]
    children: list[CreatorEdge] = Field(default_factory=list)  # type: ignore[type-arg]
    sibling_ids: list[str] = Field(default_factory=list)

    # --- textgrad hooks (G4) --------------------------------------------
    requires_grad: bool = False
    grad_learning_rate: float = 0.0

    # --- temporal & decay -------------------------------------------------
    created_at: float = Field(default_factory=_now)
    updated_at: float = Field(default_factory=_now)
    ttl: float | None = None
    last_accessed_at: float = Field(default_factory=_now)
    access_count: int = 0

    # --- lifecycle & version ---------------------------------------------
    status: NodeStatus = NodeStatus.ACTIVE
    checkpoint_id: str | None = None

    # --- scoring inputs (used by §9 retrieval) ---------------------------
    lineage_depth: int = 0
    importance: float = 0.5
    tags: list[str] = Field(default_factory=list)

    # --- feedback accumulator (G4) ---------------------------------------
    accumulated_feedback: str = ""
    feedback_count: int = 0
    last_feedback_at: float | None = None

    # ---------- validators ------------------------------------------------

    @field_validator("grad_learning_rate")
    @classmethod
    def _validate_grad_learning_rate(cls, value: float) -> float:
        """``grad_learning_rate`` must be in [0, 1] (closed interval).

        ``0.0`` is the *hard boundary* marker (architecture §7.4);
        ``1.0`` is the maximum; anything outside is a programming error
        and should be caught at write time, not at backward-pass time.
        """
        if not (0.0 <= value <= 1.0):
            raise ValueError(
                f"grad_learning_rate must be in [0, 1]; got {value!r}"
            )
        return value

    @field_validator("importance")
    @classmethod
    def _validate_importance(cls, value: float) -> float:
        if not (0.0 <= value <= 1.0):
            raise ValueError(f"importance must be in [0, 1]; got {value!r}")
        return value

    @field_validator("embedding")
    @classmethod
    def _validate_embedding(cls, value: list[float] | None) -> list[float] | None:
        """Embeddings must be 1-D float32 arrays of a fixed dimensionality.

        The dim is enforced at the *node* level too (not just the store)
        so that a bad write cannot leak into the graph. We allow ``None``
        — a node without an embedding is legal; it just isn't retriable
        via cosine search.
        """
        if value is None:
            return value
        if not value:
            raise ValueError("embedding must be non-empty when provided")
        arr = np.asarray(value, dtype=np.float32)
        if arr.ndim != 1:
            raise ValueError(
                f"embedding must be 1-D; got shape {arr.shape!r}"
            )
        # We deliberately don't hard-code DEFAULT_EMBEDDING_DIM here:
        # users with non-OpenAI embedders will have a different dim. The
        # only invariant we enforce is "1-D float32" — the store layer
        # adds per-tenant dim checks if needed.
        return arr.tolist()

    @field_validator("tags")
    @classmethod
    def _validate_tags(cls, value: list[str]) -> list[str]:
        for t in value:
            if not isinstance(t, str) or not t:
                raise ValueError("tags must be non-empty strings")
        return list(dict.fromkeys(value))  # dedupe, preserve order

    # ---------- ergonomics -----------------------------------------------

    def content_hash(self) -> str:
        """SHA-256 of the canonical JSON of the *content* fields.

        Used by the backward-pass gradient cache to detect "same input"
        without re-querying the LLM. Only the content-bearing fields
        participate — timestamps and access counters do not.
        """
        payload = {
            "content": self.content,
            "content_type": self.content_type.value,
            "structured_payload": self.structured_payload,
            "tags": self.tags,
        }
        blob = json.dumps(payload, sort_keys=True, default=str).encode("utf-8")
        return hashlib.sha256(blob).hexdigest()

    def with_appended_feedback(self, text: str, eta: float) -> MemoryNode:
        """Return a new node with one more feedback line appended.

        The original instance is untouched (frozen). The new instance
        increments ``feedback_count`` and refreshes ``last_feedback_at``
        and ``updated_at``.
        """
        stamp = f"[t={_now():.6f} eta={eta:.2f}] {text}"
        if self.accumulated_feedback:
            new_feedback = self.accumulated_feedback + "\n" + stamp
        else:
            new_feedback = stamp
        return self.model_copy(
            update={
                "accumulated_feedback": new_feedback,
                "feedback_count": self.feedback_count + 1,
                "last_feedback_at": _now(),
                "updated_at": _now(),
                "version": self.version + 1,
            }
        )

    # ---------- hashing & equality --------------------------------------

    def __hash__(self) -> int:  # type: ignore[override]
        # Identity-based hash: the ID alone is sufficient because IDs
        # are globally unique (ULIDs in production). Two nodes with the
        # same ID but different versions are the "same node" for
        # dict-key purposes — the version is the lineage marker, not
        # a new identity.
        return hash(self.id)

    # ---------- (de)serialisation ---------------------------------------

    def model_dump_json(self) -> str:  # type: ignore[override]
        """JSON string serialisation with a stable field order.

        We always emit ``id`` first so file diffs remain readable.
        """
        return self.model_dump_json()

    @classmethod
    def from_json(cls, blob: str | bytes) -> MemoryNode:
        """Inverse of ``model.model_dump_json()``.

        Accepts either ``str`` (parsed as JSON) or ``bytes`` (decoded
        as UTF-8 then parsed).
        """
        if isinstance(blob, bytes):
            blob = blob.decode("utf-8")
        return cls.model_validate_json(blob)


class CreatorEdge(BaseModel):
    """A typed edge in the provenance DAG.

    Fields mirror ``01b_pmd_architecture.md`` §4.3. The edge is a
    *fact about the world*, not a property of either endpoint — the
    store's primary key is ``(from_node_id, to_node_id, edge_type)``.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    from_node_id: str
    to_node_id: str
    edge_type: EdgeType = EdgeType.CREATED_FROM
    weight: float = 1.0
    confidence: float = 1.0
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: float = Field(default_factory=_now)
    feedback_text: str = ""
    feedback_token_cost: int = 0

    @field_validator("confidence")
    @classmethod
    def _validate_confidence(cls, value: float) -> float:
        if not (0.0 <= value <= 1.0):
            raise ValueError(f"confidence must be in [0, 1]; got {value!r}")
        return value

    @field_validator("weight")
    @classmethod
    def _validate_weight(cls, value: float) -> float:
        if value < 0.0:
            raise ValueError(f"weight must be non-negative; got {value!r}")
        return value

    def edge_key(self) -> tuple[str, str, str]:
        """The (from, to, type) tuple used as the store's primary key."""
        return (self.from_node_id, self.to_node_id, self.edge_type.value)

    def __hash__(self) -> int:  # type: ignore[override]
        return hash(self.edge_key())


__all__ = [
    "MemoryNode",
    "CreatorEdge",
    "PromptContext",
    "DEFAULT_EMBEDDING_DIM",
]
