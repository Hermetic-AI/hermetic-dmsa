"""Closed enum types for the PMD core data model.

All enums are ``str``-valued so they serialise cleanly through JSON and
SQLite TEXT columns. The values are intentionally identical to the member
names — never change a value without a migration. Adding a new member is
backwards compatible as long as the consumer code defaults are explicit.
"""

from __future__ import annotations

from enum import Enum


class EdgeType(str, Enum):
    """The five closed edge types in PMD.

    Every edge in the DAG is exactly one of these. The five types were
    chosen to cover the lineage semantics that the 16-system audit
    identified as missing (``01a_provenance_ground_truth_audit.md`` §1).
    """

    CREATED_FROM = "CREATED_FROM"
    """Edge from a :class:`~pmd.core.prompt.PromptContext` to the
    :class:`~pmd.core.node.MemoryNode` it produced. There is exactly one
    such edge per node and it is the anchor for prompt-level lineage (G1)."""

    DERIVED_FROM = "DERIVED_FROM"
    """Edge from a parent memory to a child memory that was derived from
    it (e.g. a summary, a transformed embedding, a new conclusion). The
    default edge type for ``add_memory(parents=[...])`` calls."""

    CONSOLIDATED_FROM = "CONSOLIDATED_FROM"
    """Edge from each source memory to a single consolidated output. Used
    by hebb-mind-style merge agents to record the ``N -> 1`` lineage that
    would otherwise be lost on ``purge_memory``."""

    REPLAYED_FROM = "REPLAYED_FROM"
    """Edge that records a re-hydration from a snapshot. The audit trail
    can then answer "which version did this node first appear in?"."""

    FORGOTTEN_BUT_LINKED = "FORGOTTEN_BUT_LINKED"
    """Edge from a tombstoned node to whatever replaced it. Lets the
    graph stay connected even when a memory is logically deleted."""


class PropagationStrategy(str, Enum):
    """How a backward pass chooses to walk ancestors.

    See ``01b_pmd_architecture.md`` §7.4 for the precise boundary
    semantics of each value.
    """

    FULL = "FULL"
    """Walk every reachable ancestor up to ``max_depth``. ``requires_grad``
    and ``grad_learning_rate`` are still respected as scaling factors but
    never short-circuit the traversal."""

    PARTIAL = "PARTIAL"
    """Propagate only along ``DERIVED_FROM`` edges. ``CREATED_FROM`` edges
    are skipped — the creation prompt is treated as conceptually frozen
    but the derived reasoning is not."""

    STOP_AT_GRAD_BOUNDARY = "STOP_AT_GRAD_BOUNDARY"
    """Default. ``grad_learning_rate == 0.0`` is a hard wall; traversal
    stops at the first ancestor whose gradient is disabled."""


class FeedbackSource(str, Enum):
    """Origin of a backward-pass signal."""

    USER = "USER"
    """Direct human feedback. Highest trust; ``severity`` is usually 1.0."""

    LLM_AS_JUDGE = "LLM_AS_JUDGE"
    """A second LLM was used to grade the output. Subject to LLM bias."""

    AUTOMATED_TEST = "AUTOMATED_TEST"
    """A regression test (or an ``assert``) supplied the signal."""

    HEURISTIC = "HEURISTIC"
    """An algorithmic metric — e.g. embedding drift, BLEU drop, ROUGE-L."""


class ContentType(str, Enum):
    """What kind of payload a node carries.

    The type is used by the embedding pipeline, the export format, and
    the content-aware validators in ``pmd.api.add``.
    """

    TEXT = "TEXT"
    """Plain natural-language text. The most common type."""

    EMBEDDING = "EMBEDDING"
    """Dense vector already produced by an embedder. The bytes live in
    ``node.embedding`` and ``node.content`` is empty or a placeholder."""

    STRUCTURED = "STRUCTURED"
    """A Pydantic model or a JSON object. The serialised form lives in
    ``node.structured_payload``."""

    TRIPLE = "TRIPLE"
    """A knowledge-graph triple ``(subject, predicate, object)``. Used by
    bridges that wrap cognee or HippoRAG output."""

    CODE = "CODE"
    """Source code. The text in ``node.content`` is valid in some language
    and the backward pass may invoke a static analyser."""

    IMAGE_REF = "IMAGE_REF"
    """Pointer to an image stored outside PMD (S3, local FS, blob)."""

    AUDIO_REF = "AUDIO_REF"
    """Pointer to an audio asset. Symmetric with ``IMAGE_REF``."""

    TOOL_CALL = "TOOL_CALL"
    """A tool invocation record. The ``structured_payload`` field carries
    the tool name, args, and result."""

    MESSAGE = "MESSAGE"
    """A chat message — user, assistant, or system. Used by adapters that
    lift full conversations into the graph."""


class NodeStatus(str, Enum):
    """Lifecycle state of a node.

    The status is purely a flag for query filters; it does not delete
    nodes (the graph stays connected for lineage). Setting ``DELETED``
    also writes a ``FORGOTTEN_BUT_LINKED`` edge to the replacement if
    one exists.
    """

    ACTIVE = "ACTIVE"
    """Default. Live, queryable, included in retrieval."""

    FROZEN = "FROZEN"
    """Locked from backward updates. ``grad_learning_rate`` is treated as
    0.0 regardless of the field's stored value. Used for checkpoint
    anchors that must not move."""

    DEPRECATED = "DEPRECATED"
    """Logically superseded. Excluded from default search results but
    still queryable for lineage."""

    DELETED = "DELETED"
    """Tombstoned. The node is still present in the graph (for lineage
    reasons) but a ``FORGOTTEN_BUT_LINKED`` edge is recorded and the
    node is excluded from search results."""


__all__ = [
    "EdgeType",
    "PropagationStrategy",
    "FeedbackSource",
    "ContentType",
    "NodeStatus",
]
